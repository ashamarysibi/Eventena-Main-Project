<?php 
session_start();
include 'conn.php';
if(isset($_POST['btn']))
{
    $uname =$_POST['username'];
	$pass =$_POST['password'];


$sql="select * from tbl_login where username='$uname' and log_pswd='$pass' and status='1'";


$result=mysqli_query($con,$sql);
$rowcount=mysqli_num_rows($result);
if($rowcount!=0)
{

	while($row=mysqli_fetch_array($result))
	{
		$dbu_name=$row['username'];
		$dbu_pass=$row['log_pswd'];
		$dbu_type=$row['usertype_id'];
		$id=$row['log_id'];

        
		if($dbu_name==$uname && $dbu_pass==$pass)
		{
			$_SESSION['uname']=$dbu_name;
            $_SESSION['pass']=$dbu_pass;
            $_SESSION['login']="1";
            $_SESSION['loginid']=$id;
		     
			if($dbu_type==1)	
			{
				$_SESSION['type']="Admin";
               	header("Location: Admin/admin_session.php");
			}
			else if($dbu_type==2)
			{
				$_SESSION['type']="Customer";
				$sql1="select * from tbl_userreg where log_id ='$id'";
				$result1=mysqli_query($con,$sql1);
				if($row1=mysqli_fetch_array($result1))
				$usr_name=$row1['cust_name'];
				$_SESSION['cust_name']=$usr_name;
                	header('Location: customer/cust_session.php');
			}
			else if($dbu_type==3)
			{
				
				$_SESSION['type']="Catering";
				$sql1="select * from evt_cate where log_id ='$id'";
				$result1=mysqli_query($con,$sql1);
				if($row1=mysqli_fetch_array($result1))
				$usr_name2=$row1['cmp_name'];
				$_SESSION['cmp_name']=$usr_name2;
                	header('Location: catering/catering_session.php');
			}
			else if($dbu_type==4)
			{
				
				$_SESSION['type']="Decors";
				$sql1="select * from evt_decor where log_id ='$id'";
				$result1=mysqli_query($con,$sql1);
				if($row1=mysqli_fetch_array($result1))
				$usr_name1=$row1['cmp_name'];
				$_SESSION['cmp_name']=$usr_name1;
                	header('Location: decoration/decoration_session.php');
			}
			else if($dbu_type==5)
			{
				
			    $_SESSION['type']="security";
				$sql1="select * from tbl_security where log_id ='$id'";
				$result1=mysqli_query($con,$sql1);
				if($row1=mysqli_fetch_array($result1))
				$usr_name=$row1['sec_name'];
				$_SESSION['sec_name']=$usr_name;
                	header('Location: security/security_session.php');
			}
			else if($dbu_type==6)
			{
				
			    $_SESSION['type']="photo";
				$sql1="select * from evt_photo where log_id ='$id'";
				$result1=mysqli_query($con,$sql1);
				if($row1=mysqli_fetch_array($result1))
				$usr_name=$row1['cmp_name'];
				$_SESSION['cmp_name']=$usr_name;
                	header('Location: photo/photo_session.php');
			}
			else if($dbu_type==7)
			{
				
			    $_SESSION['type']="Transport";
				$sql1="select * from evt_trans where log_id ='$id'";
				$result1=mysqli_query($con,$sql1);
				if($row1=mysqli_fetch_array($result1))
				$usr_name=$row1['cmp_name'];
				$_SESSION['cmp_name']=$usr_name;
                	header('Location: transport/trans_session.php');
			}
				else if($dbu_type==8)
			{
				
			    $_SESSION['type']="Beauty";
				$sql1="select * from evt_beauty where log_id ='$id'";
				$result1=mysqli_query($con,$sql1);
				if($row1=mysqli_fetch_array($result1))
				$usr_name=$row1['cmp_name'];
				$_SESSION['cmp_name']=$usr_name;
                	header('Location: beauty/beauty_session.php');
			}
		
		}
		else
        {
        	?>
	<script>
 alert("Invalid login credentials");
 window.location='login.php'
</script>;
<?php
				//header("location:signin.php?error=wrong password");
          //echo "wrong";
        }
	}
}
else
{
	?>
	<script>
 alert("Invalid Username and Password");
 
 window.location='login.php'
</script>;
<?php
			//header("location:signin.php?error=User Not Found");
			//echo "not found";	
}
}
?>