<?php
include 'conn.php';
?>
<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<head>
<style>
input[type=submit]{
    width: 100%;
	
	text-align: center;
  background-color: #4CAF50;
    padding: 10px 45px;
    margin: 2px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}
.sidenav a:hover {
  color: red;
  
 
}
</style>
<title>Eventena</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Match Fix Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />

    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
			
        }
function myfunction1()
{
var x=document.forms["myform"]["username"].value;
if(x=="")
{
alert("Please Fill  username Field");
document.getElementById('username').focus();
return false;
}

  
var y=document.forms["myform"]["password1"].value;
if(y=="")
{
alert("Please Fill  password Field");
document.getElementById('password1').focus();
return false;
}

return (true);

}
</script>
	
	<!-- css files -->
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css' /><!-- bootstrap css -->
    <link href="css/style.css" rel='stylesheet' type='text/css' /><!-- custom css -->
	<link href="css/css_slider.css" type="text/css" rel="stylesheet" media="all">
    <link href="css/font-awesome.min.css" rel="stylesheet"><!-- fontawesome css -->
	<!-- //css files -->
	
	<!-- google fonts -->
	<link href="//fonts.googleapis.com/css?family=Muli:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
	<!-- //google fonts -->
	
</head>

<body>

<!-- header -->
<header>
	<div class="top-head container">
		<div class="ml-auto text-right right-p">
			<ul>
				<li class="mr-3">
					<span class="fa fa-phone"></span>+91 7034068798</li>
				<li>
					<span class="fa fa-envelope-open"></span> eventena.com </li>
			</ul>
		</div>
	</div>
	<div class="container">
		<!-- nav -->
		<nav class="py-3 d-lg-flex">
			<div id="logo">
				<h1> <a href="index.html"><span class="fa fa-gift"></span> Eventena </a></h1>
			</div>
			<label for="drop" class="toggle"><span class="fa fa-bars"></span></label>
			<input type="checkbox" id="drop" />
			<ul class="menu ml-auto mt-1">
			<div class="sidenav">
				<li class="active"><a href="Home/index.html" style="font-size: 25px;">Home</a></li>
				
				<li class=""><a href="#" style="font-size: 25px;">Sign Up </a>
									<input type="checkbox" id="drop-2" />
									<ul>
										<li><a href="customer/user_reg.php" style="font-size: 17px;" class="drop-text">Customer</a></li>
										<li><a href="catering/eventplanner.php" style="font-size: 17px;" class="drop-text">Catering </a></li>
										<li><a href="../decoration/decor_reg.php" style="font-size: 17px;" class="drop-text">Decors</a></li>
										<li><a href="../transport/trans_reg.php" style="font-size: 17px;" class="drop-text">Transportation</a></li>
										<li><a href="../beauty/beauty_reg.php" style="font-size: 17px;" class="drop-text">Beautician</a></li>
										<li><a href="../photo/photo_reg.php" style="font-size: 17px;" class="drop-text">Photography</a></li>
										
									</ul></li>
				
				
				
				
			</ul>
		</nav>
		<!-- //nav -->
	</div>
	</div>
</header>
<!-- //header -->


<!-- banner -->
<div class="banner" id="home">
	<div class="layer">
		<div class="container">
			<div class="row">
				<div class="col-lg-7 banner-text-w3ls">
					<!-- banner slider-->
					<div class="csslider infinity" id="slider1">
						<input type="radio" name="slides" checked="checked" id="slides_1" />
						<input type="radio" name="slides" id="slides_2" />
						<input type="radio" name="slides" id="slides_3" />
						<ul class="banner_slide_bg">
							<li>
								<div class="container-fluid">
									<div class="w3ls_banner_txt">
										
										<h4 class="b-w3ltxt text-capitalize mt-md-2">Best Event Planning</h4>
									
										<p class="w3ls_pvt-title my-3">	Best celebrations and Creative Plans</p>
									</div>
								</div>
							</li>
							
							
						</ul>
						
					</div>
					<!-- //banner slider-->
				</div>
				<div class="col-lg-5 col-md-8 px-lg-3 px-0">
					<div class="banner-form-w3 ml-lg-5">
						<div class="padding">
							<form action="log_action.php" autocomplete="off" name="myform" method="post">
								<h5 class="mb-3">Login</h5>
								<div class="form-style-w3layout">
									<label>User Name</label>
									<input placeholder="Email Id" autocomplete="off" id="username" name="username" type="email" required="">
									<label>Password</label><input placeholder="password"  autocomplete="off" name="password" id="password"  type="password" >
							 

<!-- An element to toggle between password visibility -->
<input type="checkbox" onclick="myFunction()">Show Password&emsp;
&emsp;<a href="forgot.php">Forgot Password ?</a>
<script>
function myFunction() {
  var x = document.getElementById("password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
	</script>								<!--<input placeholder="Password" name="password" type="password" required=""> -->
									<br><button name="btn" onClick="return myfunction1();" Class="btn" >Login</button>
									
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- //footer -->

<!-- copyright -->
<section class="copyright">
	<div class="container py-5">
		<div class="row bottom">
			
			<div class="col-lg-6 copy-right p-0">
				<p class="">     Site developed by Asha mary sibi | ashamarysibi@mca.ajce.in
					
				</p>
			</div>
		</div>
	</div>
</section>
<!-- //copyright -->

<!-- move top -->
<div class="move-top text-right">
	<a href="#home" class="move-top"> 
		<span class="fa fa-angle-up  mb-3" aria-hidden="true"></span>
	</a>
</div>
<!-- move top -->
</body>
</html>
