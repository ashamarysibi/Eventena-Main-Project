<?php
include 'conn.php';
?>
<!--
author: W3layouts
author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<head>
<style>
input[type=submit]{
    width: 100%;
	
	text-align: center;
  background-color: #4CAF50;
    padding: 10px 45px;
    margin: 2px 0;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}
.sidenav a:hover {
  color: red;
  
 
}
</style>
<title>Eventena</title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Match Fix Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />

    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
			
        }


  
var y=document.forms["myform"]["password1"].value;
if(y=="")
{
alert("Please Fill  password Field");
document.getElementById('password1').focus();
return false;
}

return (true);

}
</script>
	
	<!-- css files -->
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css' /><!-- bootstrap css -->
    <link href="css/style.css" rel='stylesheet' type='text/css' /><!-- custom css -->
	<link href="css/css_slider.css" type="text/css" rel="stylesheet" media="all">
    <link href="css/font-awesome.min.css" rel="stylesheet"><!-- fontawesome css -->
	<!-- //css files -->
	
	<!-- google fonts -->
	<link href="//fonts.googleapis.com/css?family=Muli:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
	<!-- //google fonts -->
	
</head>

<body>

<!-- header -->
<header>
	<div class="top-head container">
		<div class="ml-auto text-right right-p">
			<ul>
				<li class="mr-3">
					<span class="fa fa-phone"></span>+91 7034068798</li>
				<li>
					<span class="fa fa-envelope-open"></span> eventena.com </li>
			</ul>
		</div>
	</div>
	<div class="container">
		<!-- nav -->
		<nav class="py-3 d-lg-flex">
			<div id="logo">
				<h1> <a href="index.html"><span class="fa fa-gift"></span> Eventena </a></h1>
			</div>
			<label for="drop" class="toggle"><span class="fa fa-bars"></span></label>
			<input type="checkbox" id="drop" />
			<ul class="menu ml-auto mt-1">
			<div class="sidenav">
				<li class="active"><a href="Home/index.html" style="font-size: 25px;">Home</a></li>
				
				<li class=""><a href="#" style="font-size: 25px;">Sign Up </a>
									<input type="checkbox" id="drop-2" />
									<ul>
										<li><a href="customer/user_reg.php" style="font-size: 17px;" class="drop-text">Customer</a></li>
										<li><a href="catering/eventplanner.php" style="font-size: 17px;" class="drop-text">Catering </a></li>
										<li><a href="../decoration/decor_reg.php" style="font-size: 17px;" class="drop-text">Decors</a></li>
										<li><a href="../transport/trans_reg.php" style="font-size: 17px;" class="drop-text">Transportation</a></li>
										<li><a href="../beauty/beauty_reg.php" style="font-size: 17px;" class="drop-text">Beautician</a></li>
										<li><a href="../photo/photo_reg.php" style="font-size: 17px;" class="drop-text">Photography</a></li>
										
									</ul></li>
				
				
				
				
			</ul>
		</nav>
		<!-- //nav -->
	</div>
	</div>
</header>
<!-- //header -->


<!-- banner -->
<div class="banner" id="home">
	<div class="layer">
		<div class="container">
			<div class="row">
				<div class="col-lg-7 banner-text-w3ls">
					<!-- banner slider-->
					<div class="csslider infinity" id="slider1">
						<input type="radio" name="slides" checked="checked" id="slides_1" />
						<input type="radio" name="slides" id="slides_2" />
						<input type="radio" name="slides" id="slides_3" />
						<ul class="banner_slide_bg">
							<li>
								<div class="container-fluid">
									<div class="w3ls_banner_txt">
										
										<h4 class="b-w3ltxt text-capitalize mt-md-2">Best Event Planning</h4>
									
										<p class="w3ls_pvt-title my-3">	Best celebrations and Creative Plans</p>
									</div>
								</div>
							</li>
							
							
						</ul>
						
					</div>
					<!-- //banner slider-->
				</div>
				<div class="col-lg-5 col-md-3  px-0">
					<div class="banner-form-w3 ml-lg-5">
						<div class="padding">
							<form  autocomplete="off" name="myform" method="post">
								<h5 class="mb-3">Forgot Password</h5>
								<div class="form-style-w3layout">
									<label>User Name</label>
									<input placeholder="Email Id" autocomplete="off" id="username" name="username" type="email" required=""  onChange="return myfun1()">
						
<script>
function myfun1()
{
	var f=document.forms["myform"]["username"].value;
if(f=="")
{
alert("Please Fill username Field");
document.getElementById('username').focus();
return false;
}
var uname = document.myform.username.value;
  atpos = uname.indexOf("@");
  dotpos = uname.lastIndexOf(".");
  if (uname == "" || atpos < 1 || ( dotpos - atpos < 2 )) 
  {
     alert("Please enter an Email-id as username");
	 document.getElementById('username').value = "";
   document.getElementById('username').focus();
     return false;
  }
  return (true);
}
	</script> 
									<label>New Password</label><input placeholder="password"  autocomplete="off" name="log_pswd" id="log_pswd" required=""  type="password" onChange="return myfun2()">
									<script>
function myfun2()
{
	var o=document.forms["myform"]["log_pswd"].value;
if(o=="")
{
alert("Please Fill password Field");
document.getElementById('log_pswd').focus();
return false;
}

var strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})"); 
  if(!strongRegex.test(document.myform.log_pswd.value)) 
	  {
      alert("Error: password should contain atleast one uppercase ,lowercase , digit and special characters!");
      document.getElementById('log_pswd').value = "";
	  myform.log_pswd.focus();
    return false;
     } 
return (true);
}
</script>  


									<label>New Confirm Password</label><input placeholder="Confirm password"  autocomplete="off"  required=""  name="log_pswd2" id="log_pswd2"  type="password" onChange="return myfunction12()">
							 

<script>
function myfunction12()
{
	var h=document.forms["myform"]["log_pswd2"].value;
if(h=="")
{
alert("Please Fill confirm password Field");
document.getElementById('log_pswd2').focus();
return false;
}
var pwd = document.getElementById("log_pswd").value;
       var cpwd = document.getElementById("log_pswd2").value;
        if (pwd != cpwd) {
            alert("Passwords do not match.");
			document.getElementById('log_pswd').focus();
			document.getElementById('log_pswd').value = "";
			document.getElementById('log_pswd2').value = "";
            return false;
        }
return (true);
}
	</script>  							<button name="btn" Class="btn" >Reset  Password</button>
									
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- //footer -->

<!-- copyright -->
<section class="copyright">
	<div class="container py-5">
		<div class="row bottom">
			
			<div class="col-lg-6 copy-right p-0">
				<p class="">     Site developed by Asha mary sibi | ashamarysibi@mca.ajce.in
					
				</p>
			</div>
		</div>
	</div>
</section>
<!-- //copyright -->

<!-- move top -->
<div class="move-top text-right">
	<a href="#home" class="move-top"> 
		<span class="fa fa-angle-up  mb-3" aria-hidden="true"></span>
	</a>
</div>
<!-- move top -->






<link href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css" rel="stylesheet" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/abc.js"></script>
<script type='text/Javascript'>
               function swtalert(swlt)
                {
                  if(swlt==0)
                  {
                    swal({ type: 'error',
                         title: 'Oops!',
                         text: 'Something went wrong' },
                         function()
                         {
                          window.location="forgot_page.php";
                         });
                  }
                  else if(swlt==2)
                  {
                    swal({ type: 'error',
                         title: 'Oops!',
                         text: 'New password and re-type password does not match' },
                         function()
                         {
                          window.location="forgot_page.php";
                         });
                  }
                  else if(swlt==3)
                  {
                    swal({ type: 'error',
                         title: 'Oops!',
                         text: 'You entered wrong email' },
                         function()
                         {
                          window.location="forgot_page.php";
                         });
                  }
                  else
                  {
                    swal({ type: 'success',
                         title: 'Password Changed Successfully' },
                         function()
                         {
                          window.location="login.php";
                         });
                  }
        
                }
            </script>
  
  
</body>
</html>


<?php
  
  include("conn.php");
  if(isset($_POST['btn']))
   {
    $email=$_POST['username'];
    $sq="Select * from tbl_login where username='$email'";
  $res=mysqli_query($con,$sq);
  $row=mysqli_fetch_array($res,MYSQLI_ASSOC);
  $cemail=$row['username'];
    // new password
    $pswd=$_POST['log_pswd'];
    //$pswd=md5($ps);
    $pa=$_POST['log_pswd2'];
    //$pa=md5($psw);

    //echo "<script>alert('$email')</script>";

    if(!(strcmp($cemail, $email)))
    {
      if(!(strcmp($pswd, $pa)))
      {
        if(mysqli_query($con,"Update tbl_login set log_pswd='$pswd' where username='$email'"))
        {
          echo "<script>swtalert('1');</script>";
        }
        else
        {
          echo "<script>swtalert('0');</script>";
        }
      }
      else
      {
        echo "<script>swtalert('2');</script>";
      }

       }
    else
    {
      echo "<script>swtalert('3');</script>";
    }    

    }   

  
 ?>

