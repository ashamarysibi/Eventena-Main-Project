   <?php
include 'conn.php';
?>
<?php

session_start();
 $item_id=$_GET['id']; 
$login=$_SESSION['login'];
$type=$_SESSION['type'];
$name=$_SESSION['cmp_name'];
if($login)
{
?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <title>Eventena</title>
      <!-- Meta tags -->
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <meta name="keywords" content="Summer Camp Form Responsive Widget, Audio and Video players, Login Form Web Template, Flat Pricing Tables, Flat Drop-Downs, Sign-Up Web Templates, Flat Web Templates, Login Sign-up Responsive Web Template, Smartphone Compatible Web Template, Free Web Designs for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design"
         />
      <script>
         addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); }
      </script>
      <!-- Meta tags -->
      <!-- Calendar -->
      <link rel="stylesheet" href="css2/jquery-ui.css" />
      <!-- //Calendar -->
      <!--stylesheets-->
      <link href="css2/style.css" rel='stylesheet' type='text/css' media="all">
      <!--//style sheet end here-->
      <!-- Google fonts here-->
      <link href="//fonts.googleapis.com/css?family=Barlow:300,400,500" rel="stylesheet">
      <link href="//fonts.googleapis.com/css?family=Josefin+Sans:300,400,600,700" rel="stylesheet">
      <!--//Google fonts here-->
   </head>
   <body>
      <h1 class="header-w3ls">
         Eventena
      </h1>
	  <a href="beauty_session.php" style="color: white; 
    width: 50%;
    padding: 5px 5px;
	text-decoration: none;
	 margin:0px 10px; font-size: 23px; padding:  5px 990px;"> Home </a>
	 <?php
	 $lid=$_SESSION['loginid'];

if($lid>0){
	

	

  $qry=mysqli_query($con,"select evt_beauty_id from evt_beauty where log_id='$lid'" );
  $r=mysqli_fetch_array($qry,MYSQLI_ASSOC);
	$uid=$r['evt_beauty_id'];
$select=" select * from `tbl_beauty` where evt_beauty_id='$uid' and beauty_id='$item_id' ";
 
	
	$data=mysqli_query($con,$select);
	$row=mysqli_fetch_array($data);
	?>
      <!-- multistep form -->
      <div class="main-bothside">
         <form action="#" name="myform" method="post" enctype="multipart/form-data">
            <div class="main-title">
               <h2> Update Beautician Package</h2>
            </div>
            <div class="form-group">
               <div class="form-grid-w3ls">
			           <label>Package Name</label>
                  <input type="text"  name="name" id="name" value="<?php echo $row['beauty_name']?>" readonly/>
          </div>
  
               <div class="form-grid-w3ls">

         <label> Description</label><br>
         
          <textarea rows="5" cols="54" name="desc" id="desc"  style="margin: 0px 0px 16px;
display: inline-block;
background: #ffffff;
letter-spacing: 2px;outline: none;

color: #000;
font-size: 15px;" required="true"> <?php echo $row['beauty_desc']?> </textarea>       
                           
  </div>

  </div> 
  <div class="form-group">
           
                            
  

      <div class="form-grid-w3ls">
         <label>purpose</label><br>
          <input type="text"  name="purpose" id="purpose" value="<?php echo $row['beauty_purpose']?>"readonly />
            
      </div>

      
               
          
           
         
                      <div class="form-grid-w3ls">
         <label>Price/Day</label>
          <input type="text"  name="price" id="price" placeholder="Price" value="<?php echo $row['beauty_price']?>" onChange="return myfunction7()" required/>
      
       <script>
function myfunction7()
{
  var h=document.forms["myform"]["price"].value;
if(h=="")
{
alert("Please Fill price Field");
document.getElementById('price').focus();
return false;
}
if(isNaN(h))
  {
    alert("Please Enter valid price");
    document.getElementById("price").focus();
  document.getElementById('price').value = "";
     return false;
  }
  if ((h.length < 0) || (h.length > 7))
  {
    alert("Please enter a valid price value");
    document.getElementById("price").focus();
  document.getElementById('price').value = "";
     return false;
   }
   return (true);
}
</script>  
</div></div>
         
  
  

           
            <?php 
}	
?>
               <div class="form-grid-w3ls">
            
            <!--<div class="form-control-w3l">
               <textarea name="Message" placeholder="Any Message..."></textarea>
            </div>-->
            <center><input type="submit"  name="submit" value="Update"></center>
         </div></form>
      </div>
      <div class="copy">
         <p>©2019 Site  Designed by Asha Mary Sibi</a></p>
      </div>
      <!-- js -->
      <script src='js/jquery-2.2.3.min.js'></script>
      <!-- //js -->
      <!-- Calendar -->
      <script src="js/jquery-ui.js"></script>
      <script>
         $(function () {
         	$("#datepicker,#datepicker1,#datepicker2,#datepicker3").datepicker();
         });
      </script>
      <!-- //Calendar -->
   </body>
</html>
<?php
}
else
header("location:login.php");
?>	
<?php
include("conn.php");


if(isset($_POST['submit']))
{
	
 $desc = $_POST['desc'];
   
  
   $price = $_POST['price'];  



	
$p2="update `tbl_beauty`
set 
  `beauty_desc` = '$desc',
  
  `beauty_price` = '$price'
  
  
where `beauty_id` ='$item_id'";
$ch=mysqli_query($con,$p2); 
	
if($ch)
{?>
	 <script>
 alert(" Updated");
   window.location="view_beauty.php";
</script>
	<?php
}
else
{
  echo "error:".$p2."<br>".mysqli_error($con);
   
}

}

?> 

