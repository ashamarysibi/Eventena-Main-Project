<?php
include "conn.php";

$b=$_POST['id'];
 
$sql=mysqli_query($con,"update tbl_beauty set beauty_status='1' where beauty_id='$b'");

if ( $sql  ){
echo "<script>alert(' Blocked');
     //window.location='view_beauty.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
 header("location:view_beauty.php")
 ?>