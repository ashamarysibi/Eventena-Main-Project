<?php
include 'conn.php';
?>
<?php
session_start();
$login=$_SESSION['login'];
$type=$_SESSION['type'];
$name=$_SESSION['cmp_name'];
if($login)
{
	?>


<title>Eventena</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shoppy " />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css3/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css3/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js3/jquery-2.1.1.min.js"></script> 
<!--icons-css-->
<link href="css3/font-awesome.css" rel="stylesheet"> 
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>
<!--static chart-->
<script src="js3/Chart.min.js"></script>
<!--//charts-->
<!-- geo chart -->
    <script src="//cdn.jsdelivr.net/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>
    <script>window.modernizr || document.write('<script src="lib/modernizr/modernizr-custom.js"><\/script>')</script>
    <!--<script src="lib/html5shiv/html5shiv.js"></script>-->
     <!-- Chartinator  -->
    <script src="js3/chartinator.js" ></script>
    
<!--geo chart-->

<!--skycons-icons-->
<script src="js3/skycons.js"></script>
<!--//skycons-icons-->
</head>
<body>	
<div class="page-container">	
   <div class="left-content">
	   <div class="mother-grid-inner">
            <!--header start here-->
				<div class="header-main">
					<div class="header-left">
							<div class="logo-name">
									 <a href="index3.html"> <h1>Eventena</h1> 
									<!--<img id="logo" src="" alt="Logo"/>--> 
								  </a> 								
							</div>
							<!--search-box
								<div class="search-box">
									<form>
										<input type="text" placeholder="Search..." required="">	
										<input type="submit" value="">					
									</form>
								</div><!--//end-search-box-->
							<div class="clearfix"> </div>
						 </div>
						
							<!--notification menu end -->
									<div class="profile_details">		
								<ul>
									<li class="dropdown profile_details_drop">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											<div class="profile_img">	
												<span class="prfil-img"><img src="images/img.jpg" style="width:60px;height:60px;"  alt=""> </span> 
												<div class="user-name">
													
												</div>
												<i class="fa fa-angle-down lnr"></i>
												<i class="fa fa-angle-up lnr"></i>
												<div class="clearfix"></div>	
											</div>	
										</a>
										<ul class="dropdown-menu drp-mnu">
											<!--<li> <a href="#"><i class="fa fa-cog"></i> Settings</a> </li> 
											<li> <a href="#"><i class="fa fa-user"></i> Profile</a> </li> -->
											<li><a href="beauty_profile.php"><i class="fa fa-user"></i> Profile</a> </li> 
											<li> <a href="../logout.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
																				</ul><div class="user-name">
										<?php echo "<font size=3 color = black text-align=right font-size=14px>  $name " ?></div>	</ul>
									</li>
								
							</div>
							<div class="clearfix"> </div>				
						</div>
				     <div class="clearfix"> </div>	
				</div>

<!-- script-for sticky-nav -->
		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop(); 
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });
			 
		});
		</script>

<div class="signup-page-main">
     <div class="signup-main">  	
    	<!-- <div class="signup-head">-->
				<center><h2>change password</h2></center>
			
			<div class="signup-block" >
				<form method="POST" name="myform"> 
				<label>Current Password</label><br>
					<input type="password" class="long"  placeholder="current Password" id="oldpswd"  autocomplete="off" name="oldpswd" required="true"/> 


					<label> New Password</label><br>
					<input type="password" class="long"  placeholder="New password" id="pswd1"  autocomplete="off" name="pswd1" required="true" onChange="return myfun1()"/> 
                       <font color="red">  
					   <p>* password should contain uppercase, lowercase, digit and special characters</p>
					   </font>
					   <script>
		   function myfun1(){
			   var y= document.forms["myform"]["pswd1"].value;
if(y =="")
{
alert("Please Fill  password Field");
document.getElementById('pswd1').focus();
return false;
}
if(y.length < 8){  
   alert("Password must be at least 8 characters long.");  
   document.getElementById('pswd1').focus();
   document.getElementById('pswd1').value = "";
    return false;  
}
var strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})"); 
  if(!strongRegex.test(document.myform.pswd1.value)) 
	  {
      alert("Error: password should contain atleast one uppercase,lowercase ,digit and special characters!");
      myform.pswd1.focus();
	  document.getElementById('pswd1').value = "";
    return false;
     } 
	 return true;
		   }
		  </script>
		  

			 <label>Confirm Password</label><br>
					<input type="password" class="long"  placeholder="confirm password" id="cpassword"  autocomplete="off" name="cpassword" required="true" onChange="return myfun2()"/> 
            							         
	           
				<script>
				function myfun2(){
				  
var o=document.forms["myform"]["cpassword"].value;
if(o=="")
{
alert("Please Fill confirm password Field");
document.getElementById('cpassword').focus();
return false;
}
var pwd = document.getElementById("pswd1").value;
       var cpwd = document.getElementById("cpassword").value;
        if (pwd != cpwd) {
            alert("Passwords do not match");
			document.getElementById('cpassword').focus();
			document.getElementById('cpassword').value = "";
			
            return false;
        }

return (true);

}
	</script>						
						
						<div class="clearfix"> 
					</div>
					<input type="submit" name="submit" value="Update" 	style="padding: 10px 20px;" />														
				</form>
				</div>
			</div>
  



<!--<div class="copyrights">
	 <p>© 2016 Shoppy. All Rights Reserved | Design by  <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
</div>-->	

</div>


  <div class="sidebar-menu">
		  	<div class="logo"> <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="#"> <span id="logo" ></span> 
			      <!--<img id="logo" src="" alt="Logo"/>-->
			  </a> </div>		  
		    <div class="menu">
		      <ul id="menu" >
		        
			<div class="sidebar-menu">
		  	<div class="logo"> <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="#"> <span id="logo" ></span> 
			      <!--<img id="logo" src="" alt="Logo"/>-->
			  </a> </div>		  
		    <div class="menu">
		      <ul id="menu" >
		        
				  <li id="menu-home" ><a href="add_beauty.php"><i class="fa fa-tachometer"></i><span>Add package</span></a></li>
		         
		        
		          <li id="menu-home" ><a href="view_beauty.php"><i class="fa fa-cogs"></i><span>View package</span></a></li>
		        
		        <li id="menu-home" ><a href="#"><i class="fa fa-file-text"></i><span>New Bookings</span></a> </li>
		         
				  <li id="menu-home" ><a href="#"><i class="fa fa-bar-chart"></i><span>Booking History</span></a> </li> 
				  <!-- <li id="menu-home" ><a href="viewevent_type.php"><i class="fa fa-cog"></i><span> View Events</span></a> </li> -->
			
		         <li  id="menu-home"><a href="#"><i class="fa fa-bar-chart"></i><span> View Payments</span></a></li>
		         <li  id="menu-home"><a href="#"><i class="fa fa-shopping-cart"></i><span> Make Payments</span></a></li>
<li id="menu-home" ><a href="change_pswd_beauty.php"><i class="fa fa-file-text"></i><span>change Password</span></a> </li>				  
		         
		      </ul>
		    </div>
	 </div>
	<div class="clearfix"> </div>
</div>

  <script>
var toggle = true;
            
$(".sidebar-icon").click(function() {                
  if (toggle)
  {
    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
    $("#menu span").css({"position":"absolute"});
  }
  else
  {
    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
    setTimeout(function() {
      $("#menu span").css({"position":"relative"});
    }, 400);
  }               
                toggle = !toggle;
            });
</script>
<!--scrolling js-->
		<script src="js3/jquery.nicescroll.js"></script>
		<script src="js3/scripts.js"></script>
		<!--//scrolling js-->
<script src="js3/bootstrap.js"> </script>
<!-- mother grid end here-->
</body>
</html>     
			   
	
<?php
}
else
header("location:login.php");
?>	
	
<?php
if(isset($_POST['submit']))
{
$u_id=$_SESSION['loginid'];
$old=$_POST["oldpswd"];
$new=$_POST["pswd1"];
$conf=$_POST["cpassword"];
//$log=$_SESSION['login'];
$re=mysqli_query($con,"select * from tbl_login where log_id='$u_id' and log_pswd='$old'");

if(mysqli_num_rows($re)>0)
{
	
	if ($new==$conf)
	{ 
	mysqli_query($con,"update tbl_login set log_pswd='$new' where log_id='$u_id'");
	?>
		<script>
		alert("successfully updated")
		</script>
		<?php
	}
	else
    {
        ?>
        <script>
        alert("Password MisMatch")
        </script>
    
<?php
    }
}
else
{
    ?>
    
    <script>
    alert("Current Password Mismatch")
    </script>    
    <?php }
}?>


