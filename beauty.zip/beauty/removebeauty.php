<?php
include "conn.php";

$b=$_POST['id'];
 
$sql=mysqli_query($con,"update tbl_beauty set beauty_status='0' where beauty_id='$b'");

if ( $sql  ){
echo "<script>alert(' Blocked')";
     
}
else {
	echo "<script>alert('Error');</script>";
}
 header("location:view_beauty.php")
 ?>