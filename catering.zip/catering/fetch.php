<?php  
 //fetch.php  
 $connect = mysqli_connect("localhost","root","","homeservice");  
 if(isset($_POST["cake_id"]))  
 {  
      $query = "SELECT * FROM tbl_cake WHERE cake_id = '".$_POST["cake_id"]."'";  
      $result = mysqli_query($con, $query);  
      $row = mysqli_fetch_array($result);  
      echo json_encode($row);  
 }  
 ?>