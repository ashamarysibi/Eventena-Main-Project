<?php
include 'conn.php';

	
	if(isset($_POST['insertdata']))
	{
		$id=$_POST['cake_id'];
		$name=$_POST['name'];
		$email=$_POST['item'];
		$phone=$_POST['price'];
		$sql = "UPDATE `tbl_cake` SET `pck_name`='$name',`food_name`='$email',`f_price`='$phone' WHERE cake_id=$id";
		if (mysqli_query($con, $sql)) {
			?>
		<script>alert("successfully updated");
		

  window.location="view_cakes.php";
  </script>
		<?php	
		} 
		else {
			echo '<script>alert("data not saved")';
		}
		
	}
?>






