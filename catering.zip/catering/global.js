
$('.form-disable').on('submit',function(){
	var self = $(this),
	button = self.find('input[type="submit"], button');
	submitvalue= button.data('submit-value');

	button.attr('disabled', 'disabled').val((submitvalue) ? submitvalue :'service provided..');
	return false;

});