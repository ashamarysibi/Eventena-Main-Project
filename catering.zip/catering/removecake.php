<?php
include "conn.php";

$b=$_POST['id'];
 
$sql=mysqli_query($con,"update tbl_cake set f_status='0' where cake_id='$b'");

if ( $sql  ){
echo "<script>alert(' Removed');
     window.location='view_cakes.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
 header("location:view_cakes.php")
 ?>