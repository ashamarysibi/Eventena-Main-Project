<?php
include "conn.php";

$b=$_POST['id'];
 
$sql=mysqli_query($con,"update tbl_decor set decor_status='0' where decor_id='$b'");

if ( $sql  ){
echo "<script>alert('Decoration Blocked');
     //window.location='view_dec_item.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
 header("location:view_dec_item.php")
 ?>