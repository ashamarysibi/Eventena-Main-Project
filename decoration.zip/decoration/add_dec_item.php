<!--A Design by W3layouts
   Author: W3layout
   Author URL: http://w3layouts.com
   License: Creative Commons Attribution 3.0 Unported
   License URL: http://creativecommons.org/licenses/by/3.0/
   -->
   <?php
include 'conn.php';
$q1="select * from event_type where eventtype_status='1'";
 $db2=mysqli_query($con,$q1);
?>
<?php
session_start();
$login=$_SESSION['login'];
$type=$_SESSION['type'];
$name=$_SESSION['cmp_name'];
if($login)
{
	?>


<!DOCTYPE HTML>
<html>
<head>
<title>Eventena</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shoppy " />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css3/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css3/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js3/jquery-2.1.1.min.js"></script> 
<!--icons-css-->
<link href="css3/font-awesome.css" rel="stylesheet"> 
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>
<head>
      <title>Eventena</title>
	  <h1>Add Venue</h1>
      <!-- Meta tags -->
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <meta name="keywords" content="Summer />
      <script>
         addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); }
      </script>
      <!-- Meta tags -->
      <!-- Calendar -->
      <link rel="stylesheet" href="css2/jquery-ui.css" />
      <!-- //Calendar -->
      <!--stylesheets-->
      <link href="css2/style.css" rel='stylesheet' type='text/css' media="all">
      <!--//style sheet end here-->
      <!-- Google fonts here-->
      <link href="//fonts.googleapis.com/css?family=Barlow:300,400,500" rel="stylesheet">
      <link href="//fonts.googleapis.com/css?family=Josefin+Sans:300,400,600,700" rel="stylesheet">
      <!--//Google fonts here-->
<!--static chart-->
<script src="js3/Chart.min.js"></script>
<!--//charts-->
<!-- geo chart -->
    <script src="//cdn.jsdelivr.net/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>
    <script>window.modernizr || document.write('<script src="lib/modernizr/modernizr-custom.js"><\/script>')</script>
    <!--<script src="lib/html5shiv/html5shiv.js"></script>-->
     <!-- Chartinator  -->
    <script src="js3/chartinator.js" ></script>
    
<!--geo chart-->

<!--skycons-icons-->
<script src="js3/skycons.js"></script>
<!--//skycons-icons-->
</head>
<body>	
<div class="page-container">  
   <div class="left-content">
     <div class="mother-grid-inner">
            <!--header start here-->
        <div class="header-main">
          <div class="header-left">
              <div class="logo-name">
                   <a href="index3.html"> <h1>Eventena</h1> 
                  <!--<img id="logo" src="" alt="Logo"/>--> 
                  </a>                
              </div>
              
              <div class="clearfix"> </div>
             </div>
            
              <!--notification menu end -->
              <div class="profile_details">   
                <ul>
                  <li class="dropdown profile_details_drop">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                      <div class="profile_img"> 
                        <span class="prfil-img"><img src="images/img.jpg" style="width:60px;height:60px;" alt=""> </span> 
                        
                        <i class="fa fa-angle-down lnr"></i>
                        <i class="fa fa-angle-up lnr"></i>
                        <div class="clearfix"></div>  
                      </div>  
                    </a>
                    <ul class="dropdown-menu drp-mnu">
                      <li><a href="dec_profile.php"><i class="fa fa-user"></i> Profile</a> </li> 
                      
                      <li> <a href="../logout.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
                    </ul>
                    <div class="user-name">
                    <?php echo "<font size=4 color = black> $name " ?></div>
                  </li>
                </ul>
              </div>
              <div class="clearfix"> </div>     
            </div>
           <div class="clearfix"> </div>
        </div>
 








<!--slide bar menu end here-->
      <div class="main-bothside">
         <form action="#" name="myform" method="post" enctype="multipart/form-data">
            <div class="main-title">
               <h2>Add Decoration Items</h2>
            </div>

            <div class="form-group">
			<div class="form-grid-w3ls">

			   <label>Package Name</label>
                  <input type="text"  name="name" id="name" placeholder="package Name"  required/>
				  </div>
			
               <div class="form-grid-w3ls">

			   <label>Decor Category</label>
			   <select class="form-control buttom" name="category" id="category" required/>
                     <option value="">Category
                     </option>
                    					<?php
    while($fetch=mysqli_fetch_array($db2))
						{
                            ?>
               <option value="<?php echo $fetch['eventtype_name']?>"><?php echo $fetch['eventtype_name']?>  <?php
                        }
						?>
                        </select>  
                  
                           
	</div>
	</div> 
	<div class="form-group">
               <div class="form-grid-w3ls">
			   <label>Decor Item</label><br>
                  <textarea placeholder="Items" rows="8" cols="43" id="dec" style="letter-spacing: 2px;font-size:15px;"  name="dec" autocomplete="off"   required="true"/></textarea>
				  </div>
                            
	<div class="form-grid-w3ls">
			   <label>Description</label><br>
                  <textarea placeholder="Description" rows="8" cols="43" id="desc" style="letter-spacing: 2px;font-size:15px;"  name="desc" autocomplete="off"   required="true"/></textarea>
            
			</div>
			</div>
			
            <div class="form-group">
               
               <div class="form-grid-w3ls">
			   <label>Price</label>
          <input type="text"  name="price" id="price" placeholder="Price" onChange="return myfunction7()" required/>
		  
		   <script>
function myfunction7()
{
	var h=document.forms["myform"]["price"].value;
if(h=="")
{
alert("Please Fill price Field");
document.getElementById('price').focus();
return false;
}
if(isNaN(h))
  {
    alert("Please Enter valid price");
    document.getElementById("price").focus();
	document.getElementById('price').value = "";
     return false;
  }
  if ((h.length < 0) || (h.length > 7))
  {
    alert("Please enter a valid price value");
    document.getElementById("price").focus();
	document.getElementById('price').value = "";
     return false;
   }
   return (true);
}
</script>  
</div>
           <div class="form-grid-w3ls">

			&nbsp;&nbsp;&nbsp; <label>Video</label>
                 &nbsp;&nbsp;&nbsp; <input type="file"  name="img1[]" multiple id="img1" onChange="return checkfiles()" required/>
				  
				  <script>				  
function checkfiles() {
    var formData = new FormData();
 
    var file = document.getElementById("img1").files[0];
 
    formData.append("Filedata", file);
    var t = file.type.split('/').pop().toLowerCase();
    if (t != "jpeg" && t != "mp4" && t != "avi" && t != "mov" && t != "mpeg") {
        alert('Please select a valid video file');
        document.getElementById("img1").value = '';
        return false;
    }
   if (file.size > 5242880) {
        alert('Max Upload size is 5MB only');
        document.getElementById("img1").value = '';
        return false;
    }
    return true;
}
</script>
            							         
	          </div>  
				</div>
				 
	
         
           
            

            
            <div class="form-grid-w3ls">
	
      <center><input type="submit" name="upload" value="Add Item"></center>
   </form>
		 </div>	
      </div>
    </div>
      <div class="copy">
         <p>©2019 Site  Designed by Asha Mary Sibi</a></p>
      </div>
      <!-- js -->
      <script src='js/jquery-2.2.3.min.js'></script>
      <!-- //js -->
      <!-- Calendar -->
      <script src="js/jquery-ui.js"></script>
      <script>
         $(function () {
         	$("#datepicker,#datepicker1,#datepicker2,#datepicker3").datepicker();
         });
      </script>
      <!-- //Calendar -->
</form>
  <div class="sidebar-menu">
		  	<div class="logo"> <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="#"> <span id="logo" ></span> 
			      <!--<img id="logo" src="" alt="Logo"/>-->
			  </a> </div>		  
		    <div class="menu">
		      <ul id="menu" >
		        
				  			<li id="menu-home" ><a href="add_dec_item.php"><i class="fa fa-tachometer"></i><span>Add Decoration Items</span></a></li>
		         
		        
		        <li id="menu-home" ><a href="view_dec_item.php"><i class="fa fa-cogs"></i><span>View Decoration Items</span></a></li>
		          
		        
		        <li id="menu-home" ><a href="#"><i class="fa fa-file-text"></i><span>New Bookings</span></a> </li>
		         
				  
                <li id="menu-home" ><a href="change_pswd_decor.php"><i class="fa fa-file-text"></i><span>change Password</span></a> </li>				 
		         
			      </ul>
		    </div>
	 </div>

	<div class="clearfix"> </div>
</div>
<!--slide bar menu end here-->
<script>
var toggle = true;
            
$(".sidebar-icon").click(function() {                
  if (toggle)
  {
    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
    $("#menu span").css({"position":"absolute"});
  }
  else
  {
    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
    setTimeout(function() {
      $("#menu span").css({"position":"relative"});
    }, 400);
  }               
                toggle = !toggle;
            });
</script>
<!--scrolling js-->
		<script src="js3/jquery.nicescroll.js"></script>
		<script src="js3/scripts.js"></script>
		<!--//scrolling js-->
<script src="js3/bootstrap.js"> </script>
</html>  
<?php
}
else
header("location:login.php");
?>
<html>

</body>
</html>
<!DOCTYPE html>
<html lang="en">
   
   </head>
   <body>
      
	  

      <script>
         $(function () {
         	$("#datepicker,#datepicker1,#datepicker2,#datepicker3").datepicker();
         });
      </script>
      <!-- //Calendar -->
   </body>
</html>

<?php
$msg = "";
if(isset($_POST['upload'])){
	$u_id=$_SESSION['loginid'];
  $qry=mysqli_query($con,"select evt_dec_id from evt_decor where log_id='$u_id'");
  $r=mysqli_fetch_array($qry,MYSQLI_ASSOC);
	$lid=$r['evt_dec_id'];
	for($i=0;$i<count($_FILES['img1']['name']);$i++)
	{
		$img =$_FILES['img1']['name'][$i];
        $temp_name =$_FILES['img1']['tmp_name'][$i];
        move_uploaded_file($temp_name,'../uploads/' .$img);
		$pack= $_POST['name'];
     $cate = $_POST['category'];
    $decor= $_POST['dec'];
	$desc = $_POST['desc'];
    $price = $_POST['price'];	
    $sql = "insert into tbl_decor (evt_dec_id,decor_category,pack_name,decor_item,decor_desc,decor_price,decor_image,decor_status) values('$lid','$cate','$pack','$decor','$desc','$price','$img','1')";
     $ch=mysqli_query($con,$sql);
      
      if($ch)
{?>
	 <script>
 alert("decoration package Added");
  window.location="add_dec_item.php";
</script>
	<?php
}
else
{
 
   
 echo"error:".$ch."<br>".mysqli_error($con);


	}
	}
	

}
?>





	
	
	


