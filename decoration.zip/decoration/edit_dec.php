   <?php
include 'conn.php';
?>
<?php

session_start();
 $item_id=$_GET['id']; 
$login=$_SESSION['login'];
$type=$_SESSION['type'];
$name=$_SESSION['cmp_name'];
$q1="select * from event_type where eventtype_status='1'";
 $db2=mysqli_query($con,$q1);
if($login)
{
?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <title>Eventena</title>
      <!-- Meta tags -->
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <meta name="keywords" content="Summer Camp Form Responsive Widget, Audio and Video players, Login Form Web Template, Flat Pricing Tables, Flat Drop-Downs, Sign-Up Web Templates, Flat Web Templates, Login Sign-up Responsive Web Template, Smartphone Compatible Web Template, Free Web Designs for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design"
         />
      <script>
         addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); }
      </script>
      <!-- Meta tags -->
      <!-- Calendar -->
      <link rel="stylesheet" href="css2/jquery-ui.css" />
      <!-- //Calendar -->
      <!--stylesheets-->
      <link href="css2/style.css" rel='stylesheet' type='text/css' media="all">
      <!--//style sheet end here-->
      <!-- Google fonts here-->
      <link href="//fonts.googleapis.com/css?family=Barlow:300,400,500" rel="stylesheet">
      <link href="//fonts.googleapis.com/css?family=Josefin+Sans:300,400,600,700" rel="stylesheet">
      <!--//Google fonts here-->
   </head>
   <body>
      <h1 class="header-w3ls">
         Eventena
      </h1>
	  <a href="decoration_session.php" style="color: white; 
    width: 50%;
    padding: 5px 5px;
	text-decoration: none;
	 margin:0px 10px; font-size: 23px; padding:  5px 990px;"> Home </a>
	 <?php
	 $lid=$_SESSION['loginid'];

if($lid>0){
	

	

  $qry=mysqli_query($con,"select evt_dec_id from evt_decor where log_id='$lid'" );
  $r=mysqli_fetch_array($qry,MYSQLI_ASSOC);
	$uid=$r['evt_dec_id'];
  $select=" select * from `tbl_decor` where evt_dec_id='$uid' and decor_id='$item_id' ";
 
	
	$data=mysqli_query($con,$select);
	$row=mysqli_fetch_array($data);
	?>
      <!-- multistep form -->
      <div class="main-bothside">
         <form action="#" name="myform" method="post" enctype="multipart/form-data">
            <div class="main-title">
               <h2> Update Decor Package</h2>
            </div>
            <div class="form-group">
      <div class="form-grid-w3ls">

         <label>Package Name</label>
                  <input type="text" value="<?php echo $row['pack_name'];?>" readonly name="name" id="name" required/>
          </div>
      
               <div class="form-grid-w3ls">

         <label>Decor Category</label>
         <input type="text" value="<?php echo $row['decor_category'];?>" name="category" id="category" readonly required/> 
                  
                           
  </div>
  </div> 
  <div class="form-group">
               <div class="form-grid-w3ls">
         <label>Decor Item</label><br>
                  <textarea placeholder="Items" rows="5" cols="55" id="dec" style="letter-spacing: 2px;font-size:15px;"  name="dec" autocomplete="off"   required="true"/><?php echo $row['decor_item'];?></textarea>
          </div>
                            
  <div class="form-grid-w3ls">
         <label>Description</label><br>
                  <textarea placeholder="Description" rows="5" cols="55" id="desc" style="letter-spacing: 2px;font-size:15px;"  name="desc" autocomplete="off"   required="true"/><?php echo $row['decor_desc'];?></textarea>
            
      </div>
      </div>
      
            <div class="form-group">
               
               <div class="form-grid-w3ls">
         <label>Price</label>
          <input type="text"  name="price"value="<?php echo $row['decor_price'];?>" id="price" placeholder="Price" onChange="return myfunction7()" required/>
      
       <script>
function myfunction7()
{
  var h=document.forms["myform"]["price"].value;
if(h=="")
{
alert("Please Fill price Field");
document.getElementById('price').focus();
return false;
}
if(isNaN(h))
  {
    alert("Please Enter valid price");
    document.getElementById("price").focus();
  document.getElementById('price').value = "";
     return false;
  }
  if ((h.length < 0) || (h.length > 6))
  {
    alert("Please enter a valid price value");
    document.getElementById("price").focus();
  document.getElementById('price').value = "";
     return false;
   }
   return (true);
}
</script>  
</div>
           <!--<div class="form-grid-w3ls">

      <label>Image</label><br>
                  <input type="file"  name="img1" value="<?php echo $row['decor_image'];?>" id="img1" onChange="return checkfiles()" />
            <img src="../uploads/<?php echo $row['decor_image']; ?>" width="50%" height="50%">
          <script>          
function checkfiles() {
    var formData = new FormData();
 
    var file = document.getElementById("img1").files[0];
 
    formData.append("Filedata", file);
    var t = file.type.split('/').pop().toLowerCase();
    if (t != "jpeg" && t != "jpg" && t != "png" && t != "bmp" && t != "gif") {
        alert('Please select a valid image file');
        document.getElementById("img1").value = '';
        return false;
    }
    if (file.size > 1024000) {
        alert('Max Upload size is 1MB only');
        document.getElementById("img1").value = '';
        return false;
    }
    return true;
}
</script>
                                   
            </div> --> 
        </div>
  

           
            <?php 
}	
?>
               <div class="form-grid-w3ls">
            
            <!--<div class="form-control-w3l">
               <textarea name="Message" placeholder="Any Message..."></textarea>
            </div>-->
            <center><input type="submit"  name="submit" value="Update"></center>
         </div></form>
      </div>
      <div class="copy">
         <p>©2019 Site  Designed by Asha Mary Sibi</a></p>
      </div>
      <!-- js -->
      <script src='js/jquery-2.2.3.min.js'></script>
      <!-- //js -->
      <!-- Calendar -->
      <script src="js/jquery-ui.js"></script>
      <script>
         $(function () {
         	$("#datepicker,#datepicker1,#datepicker2,#datepicker3").datepicker();
         });
      </script>
      <!-- //Calendar -->
   </body>
</html>
<?php
}
else
header("location:login.php");
?>	
<?php
include("conn.php");


if(isset($_POST['submit']))
{
//$img =$_FILES['img1']['name'];
  //      $temp_name =$_FILES['img1']['tmp_name'];
    //    move_uploaded_file($temp_name,'../uploads/' .$img);
    $pack= $_POST['name'];
     $cate = $_POST['category'];
    $decor= $_POST['dec'];
  $desc = $_POST['desc'];
    $price = $_POST['price']; 
	




	
$p2="update `tbl_decor`
set 
  `pack_name` = '$pack',
  `decor_category` = '$cate',
  `decor_item` = '$decor',
  `decor_desc` = '$desc',
  `decor_price` = '$price'
 
  
  
where `decor_id` ='$item_id'";
 $ch=mysqli_query($con,$p2);
      
      if($ch)
{
  ?>
   <script>
     window.location="view_dec_item.php";
 alert("updated");

</script>
  <?php
}
}
else
{
  
  echo "error:".$p2."<br>".mysqli_error($con);
   
}




?> 

