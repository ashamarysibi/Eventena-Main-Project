<?php
	include 'conn.php';	
	session_start();
    $login=$_SESSION['login'];
    
	if(isset($_POST['finish'])){
		$type		= '"'.$con->real_escape_string($_POST['evttype']).'"';
		
		$date 		= '"'.$con->real_escape_string(date("yy-m-d",strtotime($_POST['evtdate']))).'"';
		$time 		= '"'.$con->real_escape_string($_POST['evttime']).'"';
		$maxgst 		= '"'.$con->real_escape_string($_POST['maxgst']).'"';

		$vname 		= '"'.$con->real_escape_string($_POST['vname']).'"';
		$decor 		= '"'.$con->real_escape_string($_POST['decors']).'"';
		$cate 		= '"'.$con->real_escape_string($_POST['cate']).'"';
		$trans 		= '"'.$con->real_escape_string($_POST['trans']).'"';
		$beauty		= '"'.$con->real_escape_string($_POST['beauty']).'"';
		$photo 		= '"'.$con->real_escape_string($_POST['photo']).'"';
		$sec 	= '"'.$con->real_escape_string($_POST['security']).'"';
		$tot 	= '"'.$con->real_escape_string($_POST['res']).'"';
		$u_id=$_SESSION['loginid'];

        $qry=mysqli_query($con,"select log_id from tbl_login where log_id='$u_id'");
       $r=mysqli_fetch_array($qry,MYSQLI_ASSOC);
	     $lid1=$r['log_id'];

		$sqlInsertUser = mysqli_query($con,"INSERT INTO tbl_book (log_id, eventtype_name, evt_date, evt_time, max_gst, v_name, decor_id, cake_id, trans_id, beauty_id, photo_id, security_no, total, allott_status, book_status) VALUES('$lid1', $type, $date, $time, $maxgst, $vname, $decor , $cate, $trans, $beauty, $photo, $sec, $tot, '0','0')");
         
     
     $s1=mysqli_query($con,"select book_id from tbl_book where log_id='$u_id'  " );
	$r1=mysqli_fetch_array($s1,MYSQLI_ASSOC);
	$lid=$r1['book_id'];
	$q2= $con->query("INSERT INTO tbl_status(book_id, cate_status, decor_status, trans_status, photo_status, sec_status, beauty_status) VALUES('$lid','0','0','0','0','0','0')");
	    
		if($sqlInsertUser === false ){
	echo "error:".$sqlInsertUser."<br>".mysqli_error($con);
		}else{
			$message =  'Successfully Booked '  ;?>
		 <script>window.location='index.php?total=<?php echo $tot; ?>';</script>
<?php
		}
	}
?>
<html>
<head>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>


  <title>Eventena</title>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  

  

<style>
body{font-family:tahoma;font-size:12px;}
#signup-step{margin:auto;padding:19px;width:53%}
#signup-step li{list-style:none; float:left;padding:5px 10px;border-top:#004C9C 1px solid;border-left:#004C9C 1px solid;border-right:#004C9C 1px solid;border-radius:5px 5px 0 0;}
.active{color:#FFF;}
#signup-step li.active{background-color:#004C9C;}
#signup-form{clear:both;border:1px #004C9C solid;padding:20px;width:50%;margin:auto;}

.demoInput{padding: 10px;border: #CDCDCD 1px solid;border-radius: 4px;background-color: #FFF;width: 50%;}
.demoInputBox{padding: 6px;border: #CDCDCD 1px solid;border-radius: 4px;background-color: #FFF;width: 50%;}
.signup-error{color:#FF0000; padding-left:15px;}
.message { 
	color: #fb4314;
	font-size: 19px;
	font-weight: bold;
	padding: 10px;
	text-align: center;
	width: 100%;
}
.btnAction{padding: 5px 10px;background-color: #F00;border: 0;color: #FFF;cursor: pointer; margin-top:15px;}
label{line-height:35px;}
h1{
	margin:3px 0;
	font-size:15px;
	text-decoration: none;
	text-align:center;
}
.tLink{
	font-family:tahoma;
	size:12px;
	padding-left:0px;
	text-align:center;
}
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 180px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding-top: 40px;
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 15px;
  color: white;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 160px; /* Same as the width of the sidenav */
  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}

</style>
<script src="http://code.jquery.com/jquery-1.10.2.js"></script>
<script>
function validate() {
var output = true;
$(".signup-error").html('');
if($("#personal-field").css('display') != 'none') {
	//if(!($("#evttype").val())) {
	//	output = false;
	//	$("#name-error").html("Event Type required!");
	//}
	if(!($("#evtdate").val())) {
		output = false;
		$("#email-error").html("Date required!");
	}
	if(!($("#evttime").val())) {
		output = false;
		$("#time-error").html("Time required!");
	}	
	if(!($("#maxgst").val())) {
		output = false;
		$("#max-error").html("Maximum guests required!");
	}
	if(!($("#vname").val())) {
		output = false;
		$("#vname-error").html("Venue Name required!");
	}
	
}


return output;
}
$(document).ready(function() {
	$("#next").click(function(){
		var output = validate();
		if(output) {
			var current = $(".active");
			var next = $(".active").next("li");
			if(next.length>0) {
				$("#"+current.attr("id")+"-field").hide();
				$("#"+next.attr("id")+"-field").show();
				$("#back").show();
				$("#finish").hide();
				$(".active").removeClass("active");
				next.addClass("active");
				if($(".active").attr("id") == $("li").last().attr("id")) {
					$("#next").hide();
					$("#finish").show();				
				}
			}
		}
	});
	$("#back").click(function(){ 
		var current = $(".active");
		var prev = $(".active").prev("li");
		if(prev.length>0) {
			$("#"+current.attr("id")+"-field").hide();
			$("#"+prev.attr("id")+"-field").show();
			$("#next").show();
			$("#finish").hide();
			$(".active").removeClass("active");
			prev.addClass("active");
			if($(".active").attr("id") == $("li").first().attr("id")) {
				$("#back").hide();			
			}
		}
	});
});
</script>
<script src="jquery.min.js"></script>

</head>
<body>



	<div class="page-container">  
   <div class="left-content">
   
            <!--header start here-->
     
          <div class="header-left">
              <div class="logo-name">
              <h1>Book Event</h1> 
                  <!--<img id="logo" src="" alt="Logo"/>--> 
                               
              </div>
            
      <div class="sidenav">
<a style="color:orange;font-weight: 20px;font-family:Arial black;font-size:20px; " >Eventena</a><br>
      <a href="myprofile.php" >My Profile</a><br>
  <a href="decor_grid.php" >Decoration Packgaes</a><br>
  <a href="cate_grid.php" >Catering Services</a><br>
  <a href="beauty_grid.php" >Beauticians</a><br>
  <a href="photo_grid.php">Photography</a><br>
  <a href="trans_grid.php" >Transportation</a><br>
  
  <a href="change_pswd_user.php" >Change password</a><br>
  <a href="../logout.php">Logout</a><br>
</div>
</div>
</div>
</div>

<div class='tLink'></div><br/>

<div class="message"><?php if(isset($message)) echo $message; ?></div>
<ul id="signup-step">
	<li id="personal" class="active">Event Detail</li>
	<li id="password">Packages</li>

</ul>
<form name="frmRegistration" id="signup-form" method="post">
	<div id="personal-field">
		
		<label>Event date</label><span id="email-error" class="signup-error"></span>
		<div><input type="date" name="evtdate" id="evtdate"   class="demoInput" onChange="return myfun1()"  />
		<button type="submit" style="background-color: black;color: white;border: none;
  color: white;
  padding: 6px 10px;border-radius: 9px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  font-weight: 2px;"><a style="color:white;text-decoration: none;" href="Event/index.php">View Dates</a></button></div>
		<script>
function myfun1()
{

var UserDate = document.getElementById("evtdate").value;
var UserDate = 
var ToDate = new Date();
if (new Date(UserDate).getTime() <= ToDate.getTime())  {
    alert("The Date must be Bigger than  today date")
    document.getElementById('evtdat e').value = "";
    return false;
}
return true;
}
</script>
<label>Event Type</label><span id="name-error" class="signup-error"></span><br>
<div> <select name="evttype" id="eventtype"  class="demoInput" required>
                    <option>--select--</option>
		
			<?php
			$q1="select * from event_type";
            $db1=mysqli_query($con,$q1);
            while($fetch=mysqli_fetch_array($db1))
            {
             ?>
                
               <option value="<?php echo $fetch['eventtype_name']?>"><?php echo $fetch['eventtype_name']?>  
            <?php
            }
            ?>
                  </select></div>

	 <label>Event Time</label><span id="time-error" class="signup-error"></span>
		<div><input type="time" name="evttime" id="evttime"  class="demoInput" /></div>
		<label>Max Guests</label><span id="max-error" class="signup-error"></span>
		<div><input type="text" name="maxgst" id="maxgst"  class="demoInput" onchange="return myfun2()" />
					   <script>
function myfun2()
{
	var h=document.forms["frmRegistration"]["maxgst"].value;

if(isNaN(h))
  {
    alert("Please Enter valid Guests Number");
    document.getElementById("maxgst").focus();
	document.getElementById('maxgst').value = "";
     return false;
  }
  if ((h.length < 0) || (h.length > 7))
  {
    alert("Please enter a valid Guests Number");
    document.getElementById("maxgst").focus();
	document.getElementById('maxgst').value = "";
     return false;
   }
   return (true);
}
</script> 
		</div>
		
		<label>Venue Name</label><span id="vname-error" class="signup-error"></span>
		<div><input type="text" name="vname" id="vname"  class="demoInput" /></div>
</div>
	<div id="password-field" style="display:none;">
		
		<label>Decoration Package</label><span id="decor-error" class="signup-error"></span>
<div> 
  <select name="decors" id="decors"  class="demoInputBox" required="true">
                    <option></option>
    
      <?php

      $q1="select * from tbl_decor";
            $db1=mysqli_query($con,$q1);

            while($fetch=mysqli_fetch_array($db1))
            {
              $a=$fetch['decor_id'];
              $b=$fetch['decor_price'];

              $c=$fetch['pack_name'];
             ?>
             
               <option value="<?php echo $a ?>"> <?php echo $c ?></option>

                 
           <?php
            }

            ?>      
                    
              
        </select>
         
    
 <script type="text/javascript"> 
 $(document).ready(function(){  
      $('#decors').change(function(){  
        var total=0;
           var decor_id = $(this).val();  
           $.ajax({  
                url:"getcost_decor.php",  
                method:"POST",  
                data:{decor_id:decor_id},  
                success:function(data){ 

                     $('#res').val(data);  
                }  
           });  
      });  
 }); 
</script>
            </div> 

           
    


                  <label>Catering Package</label><span id="cate-error" class="signup-error"></span><br>
<div> <select name="cate" id="cate"  class="demoInputBox" required="true">
                    <option></option>
		
			<?php

			$q1="select * from tbl_cake";
            $db1=mysqli_query($con,$q1);

            while($fetch=mysqli_fetch_array($db1))
            {
            	$a=$fetch['cake_id'];
            	$b=$fetch['f_price'];

            	$c=$fetch['pck_name'];
             ?>
             
               <option value="<?php echo $a ?>"> <?php echo $c ?></option>

                 
           <?php
            }

            ?>      
                    
              
        </select>
          <script type="text/javascript"> 
 $(document).ready(function(){  
      $("#cate, #maxgst").change(function(){  
           var cake_id = $(this).val(); 
           var max = $('#maxgst').val();  
       
           $.ajax({  
                url:"getcost_cake.php",  
                method:"POST",  
                data:{cake_id:cake_id},  
                success:function(data){ 
                   var total=  parseFloat($('#res').val()); 
                   $('#res2').val(data); 
                   var total2= max * parseFloat($('#res2').val());
                   


                   
                      var sum =  total + total2;
                   
                      $('#res').val(sum); 
                }  
           });  
      });  
 }); 
</script>
             
  </div> 
       

    
 
           
          
                  <label>Transportation</label><span id="trans-error" class="signup-error"></span><br>
<div> <select name="trans" id="trans"  class="demoInputBox" required="true">
                    <option></option>
		
			<?php
			$q1="select * from tbl_transport";
            $db1=mysqli_query($con,$q1);
            while($fetch=mysqli_fetch_array($db1))
            {
             ?>
                
               <option value="<?php echo $fetch['trans_id']?>"><?php echo $fetch['trans_name']?>  
          <?php
            }
            ?>            
              
        </select>
         
        
<script type="text/javascript"> 
 $(document).ready(function(){  
      $('#trans').change(function(){  
           var trans_id = $(this).val(); 
            
       
           $.ajax({  
                url:"getcost_trans.php",  
                method:"POST",  
                data:{trans_id:trans_id},  
                success:function(data){ 
                   var total=  parseFloat($('#res').val()); 
                   $('#res2').val(data); 
                   var total2= parseFloat($('#res2').val())
                   


                   
                      var sum =  total + total2;
                   
                      $('#res').val(sum); 
                }  
           });  
      });  
 }); 
</script>
             
    
 
   
            </div> 
                  <label>Photography</label><span id="photo-error" class="signup-error"></span><br>
<div> <select name="photo" id="photo"  class="demoInputBox" required="true">
                    <option></option>
		
			<?php
			$q1="select * from tbl_photo";
            $db1=mysqli_query($con,$q1);
            while($fetch=mysqli_fetch_array($db1))
            {
             ?>
                
               <option value="<?php echo $fetch['photo_id']?>"><?php echo $fetch['photo_name']?>  
                     
               <?php
            }
            ?> 
        </select>
         
       <script type="text/javascript"> 
 $(document).ready(function(){  
      $('#photo').change(function(){  
           var photo_id = $(this).val(); 
            
       
           $.ajax({  
                url:"getcost_photo.php",  
                method:"POST",  
                data:{photo_id:photo_id},  
                success:function(data){ 
                   var total=  parseFloat($('#res').val()); 
                   $('#res2').val(data); 
                   var total2= parseFloat($('#res2').val())
                   


                   
                      var sum =  total + total2;
                   
                      $('#res').val(sum); 
                }  
           });  
      });  
 }); 
</script>

    
 
  
            </div> 
                            <label>Beautician</label><span id="photo-error" class="signup-error"></span><br>
<div> <select name="beauty" id="beauty"  class="demoInputBox" required="true">
                    <option></option>
		
			<?php
			$q1="select * from tbl_beauty";
            $db1=mysqli_query($con,$q1);
            while($fetch=mysqli_fetch_array($db1))
            {
             ?>
                
               <option value="<?php echo $fetch['beauty_id']?>"><?php echo $fetch['beauty_name']?>  
                     
          

  <?php
            }
            ?>     
        </select>
         
       <script type="text/javascript"> 
 $(document).ready(function(){  
      $('#beauty').change(function(){  
           var beauty_id = $(this).val(); 
            
       
           $.ajax({  
                url:"getcost_beauty.php",  
                method:"POST",  
                data:{beauty_id:beauty_id},  
                success:function(data){ 
                   var total=  parseFloat($('#res').val()); 
                   $('#res2').val(data); 
                   var total2= parseFloat($('#res2').val())
                   


                   
                      var sum =  total + total2;
                   
                      $('#res').val(sum); 
                }  
           });  
      });  
 }); 
</script>

    
 
            </div> 
                            <label>security Required(Free service)</label><span id="photo-error" class="signup-error"></span><br>
<div> <select name="security" id="security"  class="demoInputBox" required="true">
                    <option value=""></option>
                
               <option value="0">0</option>
                <option value="1">1</option>
                 <option value="2">2</option>
                  <option value="3">3</option>
                  

                  </select>
              <!--  <script type="text/javascript"> 
 $(document).ready(function(){  
      $('#security').change(function(){  
           //var sec = $(this).val(); 
            
       
           $.ajax({  
                url:"getcost_security.php",  
                method:"POST",  
                
                success:function(data){ 
                   var total=  parseFloat($('#res').val()); 
                   $('#res2').val(data); 
                   var total2=  parseFloat($('#res2').val())
                   


                   
                      var sum =  total + total2;
                   
                      $('#res').val(sum); 
                }  
           });  
      });  
 }); 
</script>--></div>
                  <label>Total</label><span id="photo-error" class="signup-error"></span><br>
                  <div>
                  	<input type="text" readonly class="demoInputBox" id="res" name="res" />
                    <input type="hidden" readonly class="demoInputBox" id="res2" name="res2" />
                    
                    
                  </div>

	</div>
	
		         
		
	
		
	</div>
	<div>
		<input class="btnAction" type="button" name="back" id="back" value="Back" style="display:none;">
		<input class="btnAction" type="button" name="next" id="next" value="Next" >
		<input class="btnAction" type="submit" name="finish" id="finish" value="Book" style="display:none;">
	</div>
	</div>
</form>

	
  <!--modal ends here-->

<!--<script type="text/javascript">
	$("#password-field").on('input','.demoInputBox',   function(){
		var total = 0;
		
		$('.demoInputBox').each(function(){
			var inputVal = $(this).val();
			if($.isNumeric(inputVal)){
				total += parseFloat(inputVal);
			}
		});
		$('#res').val(total);
	});
</script>-->





</body>

</html>
