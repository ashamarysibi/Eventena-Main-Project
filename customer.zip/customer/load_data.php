<?php  
 //load_data.php  
 $connect = mysqli_connect("localhost", "root", "", "eventmanagement");  
 $output = '';  
 if(isset($_POST["decor_id"]))  
 {  
      if($_POST["decor_id"] != '')  
      {  
           $sql = "SELECT * FROM tbl_decor WHERE decor_id = '".$_POST["decor_id"]."'";  
      }  
      else  
      {  
           $sql = "SELECT * FROM tbl_decor";  
      }  
      $result = mysqli_query($connect, $sql);  
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '<div class="col-md-3"><div style="border:1px solid #ccc; padding:40px 20px; margin-left: 150px;">'.'Price:'.$row["decor_price"].'<br>'.'Items:'.$row["decor_item"].'<br>'.'Description:'.$row["decor_desc"].'</div></div>';  
      }  
      echo $output;  
 }  
 ?>  