<?php
include "conn.php";
$term = $_POST['decors'];
if(isset($_POST['submit1']))
{
$sql = mysqli_query($con,"SELECT * FROM  tbl_decor WHERE  decor_id = '$term'");

while ($row = mysql_fetch_array($sql)){
    echo 'Product ID '.$row['product_id'];
    echo '<br/> Model: '.$row['model'];
    echo '<br/> quantity: '.$row['quantity'];
    echo '<br/><br/>';
    }	
}


?>