<?php
include "conn.php";
if (isset($_POST['photo_id'])) {
    $qry = "select * from tbl_photo where photo_id=" . $_POST['photo_id'];
    $rec = mysqli_query($con,$qry);
    if (mysqli_num_rows($rec) > 0) {
        while ($res = mysqli_fetch_array($rec)) {
            echo $res['photo_price'];
        }
    }
}
?>