<?php
include "conn.php";


    $qry = "select * from tbl_security "];
    $rec = mysqli_query($con,$qry);
    if (mysqli_num_rows($rec) > 0) {
        while ($res = mysqli_fetch_array($rec)) {
            echo  $res['sec_price'];
        }
    }

?>