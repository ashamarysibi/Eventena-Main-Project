<!--A Design by W3layouts
   Author: W3layout
   Author URL: http://w3layouts.com
   License: Creative Commons Attribution 3.0 Unported
   License URL: http://creativecommons.org/licenses/by/3.0/
   -->
    <?php
include 'conn.php';
$q1="select * from district";
 $db2=mysqli_query($con,$q1);
?>
   <?php
include 'conn.php';
?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <title>Eventena</title>
      <!-- Meta tags -->
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <meta name="keywords" content="Summer Camp Form Responsive Widget, Audio and Video players, Login Form Web Template, Flat Pricing Tables, Flat Drop-Downs, Sign-Up Web Templates, Flat Web Templates, Login Sign-up Responsive Web Template, Smartphone Compatible Web Template, Free Web Designs for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design"
         />
      <script>
         addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); }
      
	  </script>

      <!-- Meta tags -->
      <!-- Calendar -->
      <link rel="stylesheet" href="css2/jquery-ui.css" />
      <!-- //Calendar -->
      <!--stylesheets-->
      <link href="css2/style.css" rel='stylesheet' type='text/css' media="all">
      <!--//style sheet end here-->
      <!-- Google fonts here-->
      <link href="//fonts.googleapis.com/css?family=Barlow:300,400,500" rel="stylesheet">
      <link href="//fonts.googleapis.com/css?family=Josefin+Sans:300,400,600,700" rel="stylesheet">
      <!--//Google fonts here-->
   </head>
   <body>
      <h1 class="header-w3ls">
         Eventena
      </h1>
	  <a href="../Home/index.html" style="color: white; 
    width: 90%;
    padding: 5px 5px;
	text-decoration: none;
	 margin:0px 10px; font-size: 23px; padding:  5px 990px;"> Home </a>
      <!-- multistep form -->
      <div class="main-bothside">
         <form action="#" name="myform"   id="register-form" method="POST">
            <div class="main-title">
               <h2> Registration Form</h2>
            </div>
            <div class="form-group">
               <div class="form-grid-w3ls">
			   <label>Name</label>
                  <input type="text" class="long" placeholder="Name" id="cust_name" autocomplete="off"  name="cust_name"   onChange="return myfunction1()" required="true" data-error=".errorTxt5"/>
                             <script>
function myfunction1()

{
var x=document.forms["myform"]["cust_name"].value;
if(x=="")
{
alert("Please Fill name Field");
document.getElementById('cust_name').focus();
document.getElementById('cust_name').value = "";
return false;
}
 var pattern1 = new RegExp("^[a-zA-Z ]*$"); 
      if(!pattern1.test(document.myform.cust_name.value)) 
	  {
      alert("Error: Please enter valid name!");
	  document.getElementById('cust_name').value = "";
      myform.cust_name.focus();
    return false;
     }


 if ((x.length < 3) || (x.length > 30))
  {
    alert("Your Name must be 3 to 30 Character");
    document.getElementById('cust_name').focus();
	document.getElementById('cust_name').value = "";
     return false;
   }

  
    


return (true);
}

	</script>
	</div>
               <div class="form-grid-w3ls">
			   <label>Address</label><br>
                  <input type="text" id="cust_addr"   name="cust_addr" autocomplete="off"  onChange="return myfunction2()"  placeholder="Address" required="true"/>
                            <script>
function myfunction2()
{var a=document.forms["myform"]["cust_addr"].value;
if(a=="")
{
alert("Please Fill Address Field");
document.getElementById('cust_addr').focus();
document.getElementById('cust_addr').value = "";
return false;
}
return (true);
}

	</script>
	</div>
            </div>
			<div class="form-group">
               <div class="form-grid-w3ls">
			   <label>Street</label>
                  <input type="text"  name="cust_street" id="cust_street" autocomplete="off" placeholder="Street"    required="true"/>
                             

	</div>
               <div class="form-grid-w3ls">
			   <label>City</label>
                 <input type="text" name="cust_city" id="cust_city" autocomplete="off" placeholder="City"   required="true"/>
                             
	</div>
            </div>
            
            
			<div class="form-group">
               <div class="form-grid-w3ls">
			   <label>Pincode</label>
                  <input type="text"  name="cust_pin" id="cust_pin" autocomplete="off" placeholder="Pincode"  onChange="return myfunction3()"   required="true"/>
                             <script>
function myfunction3()
{if( document.myform.cust_pin.value == "" ||
           isNaN( document.myform.cust_pin.value) ||
           document.myform.cust_pin.value.length != 6 )
   {
     alert( "Please provide a valid pincode upto 6 digit" );
	 document.getElementById('cust_pin').value = "";
   document.getElementById('cust_pin').focus();
     return false;
   }

	 return (true);
}

	</script>
	</div>
               <div class="form-grid-w3ls">
			   <label>District</label>
               
			   <select class="form-control buttom" name="dist" id="dist" required/>
                     <option value="">District
                     </option>
                    					<?php
    while($fetch=mysqli_fetch_array($db2))
						{
                            ?>
               <option value="<?php echo $fetch['dist_name']?>"><?php echo $fetch['dist_name']?>  <?php
                        }
						?>
                        </select>  
                  
	</div>
            </div>
            
            
            <div class="form-group">
               <div class="form-grid-w3ls">
			   <label>Contact</label>
                  <input type="text"  name="cust_mob" id="cust_mob" autocomplete="off" placeholder="Phone"   onChange="return myfunction9()" required="true"/>
                             <script>
function myfunction9()
{if( document.myform.cust_mob.value == "" ||
           isNaN( document.myform.cust_mob.value) ||
           document.myform.cust_mob.value.length != 10 )
   {
     alert( "Please provide a valid Mobile Number upto 10 digit" );
	 document.getElementById('cust_mob').value = "";
   document.getElementById('cust_mob').focus();
     return false;
   }
   var pattern = new RegExp("^([6-9]{1})([0-9]{9})$"); 
      if(!pattern.test(document.myform.cust_mob.value)) 
	  {
      alert("Error: Phone Number is invalid!");
	  document.getElementById('cust_mob').value = "";
      myform.cust_mob.focus();
    return false;
     }
	 return (true);
}

	</script>
	</div>
               <div class="form-grid-w3ls">
			   <label>Username</label>
                 <input type="email" name="username" id="username" autocomplete="off" placeholder="Username(Emailid)"  onChange="return myfunction4()" required="true"/>
                             <script>
function myfunction4()
{var f=document.forms["myform"]["username"].value;
if(f=="")
{
alert("Please Fill username Field");
document.getElementById('username').focus();
document.getElementById('username').value = "";
return false;
}
var uname = document.myform.username.value;
  atpos = uname.indexOf("@");
  dotpos = uname.lastIndexOf(".");
  if (uname == "" || atpos < 1 || ( dotpos - atpos < 2 )) 
  {
	 alert("Please enter an Email-id as username")
   document.getElementById('username').focus();
   document.getElementById('username').value = "";
     return false;
  }

return (true);
}

	</script>
	</div>
            </div>
            
            
             
            <div class="form-group">
               <div class="form-grid-w3ls">
			   <label>Password</label>
                  <input type="password" name="log_pswd" id="log_pswd" autocomplete="off" placeholder="password"  onChange="return myfunction5()" required="true"/>
            <font color="red">  <p>* password should contain  uppercase,lowercase,digit and special characters</p></font><script>
function myfunction5()
{var o=document.forms["myform"]["log_pswd"].value;
if(o=="")
{
alert("Please Fill password Field");
document.getElementById('log_pswd').focus();
return false;
}
if(o.length<8){  
   alert("Password must be at least 8 characters long.");  
   document.getElementById('log_pswd').focus();
   document.getElementById('log_pswd').value = "";
    return false;  
}

var strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})"); 
  if(!strongRegex.test(document.myform.log_pswd.value)) 
	  {
      alert("Error: password should contain atleast one uppercase,lowercase ,digit and special characters!");
      document.getElementById('log_pswd').value = "";
	  myform.log_pswd.focus();
    return false;
     } 
	 return (true);
}

   
	</script>
               </div>
               <div class="form-grid-w3ls">
			   <label>Confirm Password</label>
                  <input type="password" name="log_pswd2" id="log_pswd2" autocomplete="off" placeholder="confirm Password"  onChange="return myfunction6()"  required="true"/>
               <script>
function myfunction6()
{var h=document.forms["myform"]["log_pswd2"].value;
if(h=="")
{
alert("Please Fill confirm password Field");
document.getElementById('log_pswd2').focus();
return false;
}
var pwd = document.getElementById("log_pswd").value;
       var cpwd = document.getElementById("log_pswd2").value;
        if (pwd != cpwd) {
            alert("Passwords do not match.");
			document.getElementById('log_pswd').focus();
			document.getElementById('log_pswd').value = "";
			document.getElementById('log_pswd2').value = "";
            return false;
        }
		return (true);
}

	</script></div>
            </div>
            <div class="main-title">
               
            </div>
            
            <!--<div class="form-control-w3l">
               <textarea name="Message" placeholder="Any Message..."></textarea>
            </div>-->
            <center><input type="submit"  name="submit" value="Submit"></center>
         </form>
      </div>
      <div class="copy">
         <p>©2019 Site  Designed by Asha Mary Sibi</a></p>
      </div>
      <!-- js -->
      <script src='js/jquery-2.2.3.min.js'></script>
	  <script src="https://code.jquery.com/jquery-3.3.1.min.js"</script>
	  <script type="text/javascript" src="js/plugins/jquery-1.11.2.min.js"></script>  
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     	<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
       <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	   <script src="cust_reg_validation.js"></script>	  
      <!-- //js -->
      <!-- Calendar -->
      <script src="js/jquery-ui.js"></script>
      <script>
         

$("#register-form").validate({

      rules:{
          //username is the name of the textbox
          cust_name: {
              required: true,
              //alphanumeric:true
          },
          cust_addr: {
              required: true
          },

          cust_mob: {
              required: true,
              //customEmail: true
          },
          username:{
              required:true,
              //number:true,
              //maxlength:10,
              //minlength:10
          },
          log_pswd1: {
              required: true,
              //passstrength: true,
              //minlength:8
          },
          log_pswd2: {
              required: true,
              //equalTo: '#password'
          },
         



          

      },
      messages:{

          cust_name:{
            required: 'please enter Customer Name!'
          },
          cust_addr:{
            required: 'Please enter the Address!'
          },

          cust_mob:{
            required: 'please enter the contact Number!'
          },
          username:{
            required: 'Please enter Username!'
          },

          log_pswd1: {
              //error message for the required field
              required: 'Please enter password!'
          },
          log_pswd2: {
              required: 'Please enter confirm password!',
              //error message for the email field
              //email: 'Please enter valid email!'
          },
          

          

      },

  });
      </script>
      <!-- //Calendar -->
   </body>
</html>
<?php

if(isset($_POST['submit']))
{
$name=$_POST["cust_name"];
$addr=$_POST["cust_addr"];
$street=$_POST['cust_street'];
$city=$_POST['cust_city'];
$pin=$_POST['cust_pin'];
$dist=$_POST['dist'];
$mob=$_POST["cust_mob"];



$u=$_POST["username"];
$e=$_POST["log_pswd"];

	
$q2="insert into tbl_login(`usertype_id`,`username`,`log_pswd`,`status`) values(2,'$u','$e',1)";
if(mysqli_query($con,$q2))
{
	$s=mysqli_query($con,"select log_id from tbl_login where username='$u' and log_pswd='$e'" );
	$r=mysqli_fetch_array($s,MYSQLI_ASSOC);
	$lid=$r['log_id'];
	

$p2="insert into tbl_userreg(`log_id`,`cust_name`,`cust_addr`,`cust_street`,`cust_city`,`cust_pincode`,`cust_district`,`cust_mob`,`status`) VALUES('$lid','$name','$addr','$street','$city','$pin','$dist','$mob',1)";
$ch=mysqli_query($con,$p2);

if($ch)
{?>
	 <script>
 alert("Regesteration Successfull");
   window.location="../login.php";
</script>
	<?php
}
else
{
  echo"error:".$p2."<br>".mysqli_error($con);
   
}
}
else
{?>
	<script>
 alert("Username  Already Exists ");
</script>
<?php
}
}
mysqli_close($con);
?>



