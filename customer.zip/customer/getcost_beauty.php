<?php
include "conn.php";
if (isset($_POST['beauty_id'])) {
    $qry = "select * from tbl_beauty where beauty_id=" . $_POST['beauty_id'];
    $rec = mysqli_query($con,$qry);
    if (mysqli_num_rows($rec) > 0) {
        while ($res = mysqli_fetch_array($rec)) {
            echo $res['beauty_price'];
        }
    }
}
?>