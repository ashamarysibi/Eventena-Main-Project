<?php
include "conn.php";
if (isset($_POST['trans_id'])) {
    $qry = "select * from tbl_transport where trans_id=" . $_POST['trans_id'];
    $rec = mysqli_query($con,$qry);
    if (mysqli_num_rows($rec) > 0) {
        while ($res = mysqli_fetch_array($rec)) {
            echo $res['trans_price'];
        }
    }
}
?>
