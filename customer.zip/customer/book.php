<?php   
 //load_data_select.php  
 $connect = mysqli_connect("localhost", "root", "", "eventmanagement"); 
include "conn.php";

 function fill_brand($connect)  
 {  
      $output = '';  
      $sql = "SELECT * FROM tbl_decor";  
      $result = mysqli_query($connect, $sql);  
      while($row = mysqli_fetch_array($result))  
      {  
               
           $output .= '<option value="'.$row["decor_id"].'">'.$row["pack_name"].'</option>';  
      }  
      return $output;  
      
 }  
 
 function fill_product($con)  
 {  
      $output = '';  
      $sql = "SELECT * FROM evt_cate";  
      $result = mysqli_query($con, $sql);  
      while($row = mysqli_fetch_array($result))  
      {  
           $output .= '<div class="col-md-3">';  
           $output .= '<div style="border:1px solid #ccc; padding: 10px;border: #CDCDCD 1px solid;border-radius: 4px;background-color: #FFF;width: 50% margin-bottom:20px;">'.$row["cmp_name"].'';  
           $output .=     '</div>';  
           //$output .=     '</div>';  
      }  
     // return $output;  
 }  
 ?>  
 
             
      
           <div class="container">  
                 
                     <select name="brand" id="brand">  
                          <option value="">Select</option>  
                          <?php echo fill_brand($connect); ?>  
                     </select>  
                     <br /><br />  
                     <div class="row" id="show_product">  
                          <?php echo fill_product($connect);?>  
                     </div>  
                 
           </div>  
      </body>  
 </html>  
 <script>  
 $(document).ready(function(){  
      $('#brand').change(function(){  
           var decor_id = $(this).val();  
           $.ajax({  
                url:"load_data.php",  
                method:"POST",  
                data:{decor_id:decor_id},  
                success:function(data){  
                     $('#show_product').html(data);  
                }  
           });  
      });  
 });  
 </script> 