<?php 
include "conn.php";
if (isset($_POST['decor_id'])) {
    $qry = "select * from tbl_decor where decor_id=" . $_POST['decor_id'];
    $rec = mysqli_query($con,$qry);
    if (mysqli_num_rows($rec) > 0) {
        while ($res = mysqli_fetch_array($rec)) {
            echo $res['decor_price'];
        }
    }
}
if (isset($_POST['cake_id'])) {
    $qry = "select * from tbl_cake where cake_id=" . $_POST['cake_id'];
    $rec = mysqli_query($con,$qry);
    if (mysqli_num_rows($rec) > 0) {
        while ($res = mysqli_fetch_array($rec)) {
            echo $res['f_price'];
        }
    }
}
die();
?>