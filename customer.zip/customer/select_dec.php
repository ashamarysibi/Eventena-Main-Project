<?php
include "conn.php";


	$name=$_GET['decor_id'];
	$query=mysqli_query($con,"select * from tbl_decor where pck_name='$name'");
	$customer =mysqli_fetch_object($query);
	echo json_encode($customer);

	
?>