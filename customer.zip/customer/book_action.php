<?php
	include 'conn.php';	
	session_start();
    $login=$_SESSION['login'];
	if(isset($_POST['finish'])){
		$type		= '"'.$con->real_escape_string($_POST['evttype']).'"';
		
		$date 		= '"'.$con->real_escape_string($_POST['evtdate']).'"';
		$time 		= '"'.$con->real_escape_string($_POST['evttime']).'"';
		$maxgst 		= '"'.$con->real_escape_string($_POST['maxgst']).'"';

		$vname 		= '"'.$con->real_escape_string($_POST['vname']).'"';
		$decor 		= '"'.$con->real_escape_string($_POST['decor']).'"';
		$cate 		= '"'.$con->real_escape_string($_POST['cate']).'"';
		$trans 		= '"'.$con->real_escape_string($_POST['trans']).'"';
		$beauty		= '"'.$con->real_escape_string($_POST['beauty']).'"';
		$photo 		= '"'.$con->real_escape_string($_POST['photo']).'"';
		
		$sec 	= '"'.$con->real_escape_string($_POST['security']).'"';
		$u_id=$_SESSION['loginid'];
         $qry=mysqli_query($con,"select log_id from tbl_login where log_id='$u_id'");
        $r=mysqli_fetch_array($qry,MYSQLI_ASSOC);
	      $lid=$r['log_id'];
		$sqlInsertUser = $con->query("INSERT INTO tbl_book (log_id, eventtype_name, evt_date, evt_time, max_gst, v_name, decor_id, cate_id, trans_id, beautician, photo, security) VALUES('$lid', $type, $date, $time, $maxgst, $vname, $decor, $cate, $trans, $beauty, $photo, $sec)");
 
		if($sqlInsertUser === false){
			$message = 'Error: ' . $con->error;
		}else{
			$message =  'Successfully Booked '  ; 
		}
	}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Eventena</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shoppy " />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css3/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css3/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js3/jquery-2.1.1.min.js"></script> 
<!--icons-css-->
<link href="css3/font-awesome.css" rel="stylesheet"> 
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>
<!--static chart-->
<script src="js3/Chart.min.js"></script>
<!--//charts-->
<!-- geo chart -->
    <script src="//cdn.jsdelivr.net/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>
    <script>window.modernizr || document.write('<script src="lib/modernizr/modernizr-custom.js"><\/script>')</script>
    <!--<script src="lib/html5shiv/html5shiv.js"></script>-->
     <!-- Chartinator  -->
    <script src="js3/chartinator.js" ></script>

<!--geo chart-->

<!--skycons-icons-->
<script src="js3/skycons.js"></script>
<script>
function validate() {
var output = true;
$(".signup-error").html('');
if($("#personal-field").css('display') != 'none') {
	//if(!($("#evttype").val())) {
	//	output = false;
	//	$("#name-error").html("Event Type required!");
	//}
	if(!($("#evtdate").val())) {
		output = false;
		$("#email-error").html("Date required!");
	}
	if(!($("#evttime").val())) {
		output = false;
		$("#time-error").html("Time required!");
	}	
	if(!($("#maxgst").val())) {
		output = false;
		$("#max-error").html("Maximum guests required!");
	}
	if(!($("#vname").val())) {
		output = false;
		$("#vname-error").html("Venue Name required!");
	}
	
}


return output;
}
$(document).ready(function() {
	$("#next").click(function(){
		var output = validate();
		if(output) {
			var current = $(".active");
			var next = $(".active").next("li");
			if(next.length>0) {
				$("#"+current.attr("id")+"-field").hide();
				$("#"+next.attr("id")+"-field").show();
				$("#back").show();
				$("#finish").hide();
				$(".active").removeClass("active");
				next.addClass("active");
				if($(".active").attr("id") == $("li").last().attr("id")) {
					$("#next").hide();
					$("#finish").show();				
				}
			}
		}
	});
	$("#back").click(function(){ 
		var current = $(".active");
		var prev = $(".active").prev("li");
		if(prev.length>0) {
			$("#"+current.attr("id")+"-field").hide();
			$("#"+prev.attr("id")+"-field").show();
			$("#next").show();
			$("#finish").hide();
			$(".active").removeClass("active");
			prev.addClass("active");
			if($(".active").attr("id") == $("li").first().attr("id")) {
				$("#back").hide();			
			}
		}
	});
});
</script>
<!--//skycons-icons-->
</head>
<style>
body{font-family:tahoma;font-size:12px;}
#signup-step{margin:auto;padding:19px;width:53%}
#signup-step li{list-style:none; float:left;padding:5px 10px;border-top:#004C9C 1px solid;border-left:#004C9C 1px solid;border-right:#004C9C 1px solid;border-radius:5px 5px 0 0;}
.active{color:#FFF;}
#signup-step li.active{background-color:#004C9C;}
#signup-form{clear:both;border:1px #004C9C solid;padding:20px;width:50%;margin:auto;}
.demoInputBox{padding: 8px;border: #CDCDCD 1px solid;border-radius: 4px;background-color: #FFF;width: 70%;margin-left:50px;}
.signup-error{color:#FF0000; padding-left:15px;}
.message { 
	color: #fb4314;
	font-size: 15px;
	font-weight: bold;
	padding: 10px;
	text-align: center;
	width: 100%;
}
#label{
	margin-left:50px;
	font-size:15px;
}
.btnAction{padding: 5px 10px;background-color: #F00;border: 0;color: #FFF;cursor: pointer; margin-top:15px; margin-left:50px;}
label{line-height:35px;}
h1{
	margin:3px 0;
	font-size:13px;
	text-decoration:underline;
	text-align:center;
}
.tLink{
	font-family:tahoma;
	size:12px;
	padding-left:10px;
	text-align:center;
}




</style>
<body>	
<div class="page-container">	
   <div class="left-content">
	   <div class="mother-grid-inner">
            <!--header start here-->
				<div class="header-main">
					<div class="header-left">
							<div class="logo-name">
									 <a href="index3.html"> <h1>Eventena</h1> 
									<!--<img id="logo" src="" alt="Logo"/>--> 
								  </a> 	

							</div>
							
							<div class="clearfix"> </div>
						 </div>
						
							<!--notification menu end -->

									<div class="profile_details">		
								<ul>
									<li class="dropdown profile_details_drop">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											<div class="profile_img">	
												<span class="prfil-img"><img src="images/img.jpg" style="width:60px;height:60px;" alt=""> </span> 
												
												<i class="fa fa-angle-down lnr"></i>
												<i class="fa fa-angle-up lnr"></i>
												<div class="clearfix"></div>	
											</div>	
										</a>
										<ul class="dropdown-menu drp-mnu">

											<li> <a href="myprofile.php"><i class="fa fa-user"></i> Profile</a> </li> 
											<li> <a href="../logout.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
										</ul>
										<div class="user-name">
										<?php echo "<font size=4 color = black>  " ?></div>
									</li>
								</ul>
							</div>
							<div class="clearfix"> </div>			
						</div>
				   <div class="clearfix"> </div>
				</div>


</div>
</div>

  <div class="sidebar-menu">
		  	<div class="logo"> <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="#"> <span id="logo" ></span> 
			      <!--<img id="logo" src="" alt="Logo"/>-->
			  </a> </div>		  
		    <div class="menu">
		      <ul id="menu" >
		        
				  <li id="menu-home" ><a href="multipleforms.php"><i class="fa fa-tachometer"></i><span>Book Event</span></a></li>
		         
		        </li>
		         <li id="menu-home" ><a href="../customer/book_history.php"><i class="fa fa-cogs"></i><span>Booking History</span></a> </li>
		          
		        
		        
				   
			<li id="menu-home" ><a href="../customer/venue_grid.php"><i class="fa fa-cogs"></i><span>View Venue</span></a> </li>
		         <li  id="menu-home"><a href="../customer/view_menu.php"><i class="fa fa-bar-chart"></i><span> View menu</span></a></li>
		         <li  id="menu-home"><a href="#"><i class="fa fa-shopping-cart"></i><span> Make Payments</span></a></li>	
		         <li id="menu-home" ><a href="../customer/change_pswd_user.php"><i class="fa fa-file-text"></i><span>change Password</span></a> </li>				 
		      </ul>
		    </div>
	 </div>
	<div class="clearfix"> </div>
</div>

<div class='tLink'></div>
<h1>Book Event</h1>
<div class="message"><?php if(isset($message)) echo $message; ?></div>
<ul id="signup-step">
	<li id="personal" class="active">Event Detail</li>
	<li id="password">Packages</li>
	<li id="general">other details</li>
</ul>
<form name="frmRegistration" id="signup-form" method="post">
	<div id="personal-field">
		<label id="label">Event Type</label><span id="name-error" class="signup-error"></span><br>
<div> <select name="evttype" id="eventtype"  class="demoInputBox" required="true">
                    <option>--select--</option>
		
			<?php
			$q1="select * from event_type";
            $db1=mysqli_query($con,$q1);
            while($fetch=mysqli_fetch_array($db1))
            {
             ?>
                
               <option value="<?php echo $fetch['eventtype_id']?>"><?php echo $fetch['eventtype_name']?>  
            <?php
            }
            ?>
                  </select></div>

		<label id="label">Event date</label><span id="email-error" class="signup-error"></span>
		<div><input type="date" name="evtdate" id="evtdate" class="demoInputBox" /></div>
	 <label id="label">Event Time</label><span id="time-error" class="signup-error"></span>
		<div><input type="time" name="evttime" id="evttime" class="demoInputBox" /></div>
		<label id="label">Max Guests</label><span id="max-error" class="signup-error"></span>
		<div><input type="text" name="maxgst" id="maxgst" class="demoInputBox" /></div>
		<label id="label">Venue Name</label><span id="vname-error" class="signup-error"></span>
		<div><input type="text" name="vname" id="vname" class="demoInputBox" /></div>
</div>
	<div id="password-field" style="display:none;">
		
		<label id="label">Decoration Package</label><span id="decor-error" class="signup-error"></span><br>
<div> <select name="decor" id="decor"  class="demoInputBox">
                    <option>--select--</option>
		
			<?php
			$q1="select * from tbl_decor";
            $db1=mysqli_query($con,$q1);
            while($fetch=mysqli_fetch_array($db1))
            {
             ?>
                
               <option value="<?php echo $fetch['decor_id']?>"><?php echo $fetch['pack_name']?>  
            <?php
            }
            ?>
                  </select></div>
                  <label id="label">Catering Package</label><span id="cate-error" class="signup-error"></span><br>
<div> <select name="cate" id="cate"  class="demoInputBox">
                    <option>--select--</option>
		
			<?php
			$q1="select * from tbl_cake";
            $db1=mysqli_query($con,$q1);
            while($fetch=mysqli_fetch_array($db1))
            {
             ?>
                
               <option value="<?php echo $fetch['cake_id']?>"><?php echo $fetch['pck_name']?>  
            <?php
            }
            ?>
                  </select></div>
                  <label id="label">Transportation</label><span id="trans-error" class="signup-error"></span><br>
<div> <select name="trans" id="trans"  class="demoInputBox">
                    <option>--select--</option>
		
			<?php
			$q1="select * from tbl_transport";
            $db1=mysqli_query($con,$q1);
            while($fetch=mysqli_fetch_array($db1))
            {
             ?>
                
               <option value="<?php echo $fetch['trans_id']?>"><?php echo $fetch['trans_name']?>  
            <?php
            }
            ?>
                  </select></div>
                  <label id="label">Photography</label><span id="photo-error" class="signup-error"></span><br>
<div> <select name="photo" id="photo"  class="demoInputBox">
                    <option>--select--</option>
		
			<?php
			$q1="select * from tbl_photo";
            $db1=mysqli_query($con,$q1);
            while($fetch=mysqli_fetch_array($db1))
            {
             ?>
                
               <option value="<?php echo $fetch['photo_id']?>"><?php echo $fetch['photo_name']?>  
            <?php
            }
            ?>
                  </select></div>
                            <label id="label">Beautician</label><span id="photo-error" class="signup-error"></span><br>
<div> <select name="beauty" id="beauty"  class="demoInputBox">
                    <option>--select--</option>
		
			<?php
			$q1="select * from tbl_beauty";
            $db1=mysqli_query($con,$q1);
            while($fetch=mysqli_fetch_array($db1))
            {
             ?>
                
               <option value="<?php echo $fetch['beauty_id']?>"><?php echo $fetch['beauty_name']?>  
            <?php
            }
            ?>
                  </select></div>
	</div>
	<div id="general-field" style="display:none;">
		                         <label>security Required</label><span id="photo-error" class="signup-error"></span><br>
<div> <select name="security" id="security"  class="demoInputBox">
                    <option value="">--select--</option>
                
               <option value="0">0</option>
                <option value="1">1</option>
                 <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>

                  </select></div>
		
	</div>
		
	</div>
	<div>
		<input class="btnAction" type="button" name="back" id="back" value="Back" style="display:none;">
		<input class="btnAction" type="button" name="next" id="next" value="Next" >
		<input class="btnAction" type="submit" name="finish" id="finish" value="Finish" style="display:none;">
	</div>
</form>
<!--slide bar menu end here-->
<script>
var toggle = true;
            
$(".sidebar-icon").click(function() {                
  if (toggle)
  {
    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
    $("#menu span").css({"position":"absolute"});
  }
  else
  {
    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
    setTimeout(function() {
      $("#menu span").css({"position":"relative"});
    }, 400);
  }               
                toggle = !toggle;
            });
</script>
<!--scrolling js-->
		<script src="js3/jquery.nicescroll.js"></script>
		<script src="js3/scripts.js"></script>
		<!--//scrolling js-->
<script src="js3/bootstrap.js"> </script>

<!-- mother grid end here-->
</body>
</html>  

