<?php
session_start();
include('conn.php');
$login=$_SESSION['login'];
$type=$_SESSION['type'];
$usr_name=$_SESSION['cust_name'];
//$cash=$_GET['amount'];
if($login)
{
    ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Credit Card Payment</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="font-awesome/css/font-awesome.min.css" />
  <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
   <link href="http://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
   <script src="js/3dslider.js"></script>
<script src="js/jquery-2.1.1.min.js"></script> 
    <script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">

<div class="page-header">
   <center><h1><b>Tourism Alappuzha</b></h1></center> 
</div>

<!-- Credit Card Payment Form - START -->

<div class="container">
    <div class="row">
        <div class="col-xs-12 col-md-4 col-md-offset-4">
            <div class="panel panel-default">
               
                    <div class="row">
                       <center>
<!--                        <img src="../images/greentick.jpg" width=250 height=200>--><h4>SUCCESS</h4>
                           </center>
                    </div>
                
                <div class="panel-body">
                    <form role="form" method="post">
                     <br>
                         <div class="row">
                            <div class="col-xs-12">
                                <div class="form-group">
                                   <center> <p style="color:green;font-size:19px;"><b>Payment Successfull!</b></p>
                                    <p>Your registration was successfull.Please <a href="cust_session.php">click here</a> to go back to Home</p></center>
                                         </div>
                            </div>
                        </div>
                       
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    .cc-img {
        margin: 0 auto;
    }
</style>
<!-- Credit Card Payment Form - END -->

</div>

</body>
</html>
<?php
}
else
  header("location:index.php");
?>