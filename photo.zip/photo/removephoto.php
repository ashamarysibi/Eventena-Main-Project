<?php
include "conn.php";

$b=$_POST['id'];
 
$sql=mysqli_query($con,"update tbl_photo set photo_status='0' where photo_id='$b'");

if ( $sql  ){
echo "<script>alert(' Blocked');
     //window.location='view_photo_pck.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
 header("location:view_photo_pck.php")
 ?>