<html>
<body>
<?php
$server='localhost';
$user ='root';
$pwd="";
$dbname="Eventmanagement";
$con=new mysqli($server,$user,$pwd,$dbname);
if($con)  
    {
     echo"db connection ok";
    }
else
{
echo"not connected";
    }

?>
</body>
</html>