<?php
include "conn.php";

$b=$_POST['id'];
 
$sql=mysqli_query($con,"update tbl_login set status='1' where log_id='$b'");
$sql1=mysqli_query($con,"update evt_beauty set cmp_status='1' where log_id='$b'");
if ( $sql && $sql1 ){
echo "<script>alert(' Blocked');
     window.location='add_evt_beauty.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
 header("location:add_evt_beauty.php")
 ?>