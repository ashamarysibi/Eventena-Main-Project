<?php
include "conn.php";

$b=$_POST['id'];
 
$sql=mysqli_query($con,"update tbl_security set sec_status='0' where log_id='$b'");

if ( $sql  ){
echo "<script>alert(' Blocked');
     window.location='view_security.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
 header("location:view_security.php")
 ?>