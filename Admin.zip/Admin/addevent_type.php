<!--Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php

session_start();
$login=$_SESSION['login'];
$type=$_SESSION['type'];
if($login)
{
?>

<!DOCTYPE HTML>
<html>
<head>
<?php
include "conn.php"
?>
<title>Eventena</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shoppy " />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css3/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css3/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js3/jquery-2.1.1.min.js"></script> 
<!--icons-css-->
<link href="css3/font-awesome.css" rel="stylesheet"> 
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>
<!--static chart-->
<script src="js3/Chart.min.js"></script>
<!--//charts-->
<!-- geo chart -->
    <script src="//cdn.jsdelivr.net/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>
    <script>window.modernizr || document.write('<script src="lib/modernizr/modernizr-custom.js"><\/script>')</script>
    <!--<script src="lib/html5shiv/html5shiv.js"></script>-->
     <!-- Chartinator  -->
    <script src="js3/chartinator.js" ></script>
    
<!--geo chart-->

<!--skycons-icons-->
<script src="js3/skycons.js"></script>
<!--//skycons-icons-->
</head>
<body>	
<div class="page-container">	
   <div class="left-content">
	   <div class="mother-grid-inner">
            <!--header start here-->
				<div class="header-main">
					<div class="header-left">
							<div class="logo-name">
									 <a href="index3.html"> <h1>Eventena</h1> 
									<!--<img id="logo" src="" alt="Logo"/>--> 
								  </a> 								
							</div>
							<!--search-box
								<div class="search-box">
									<form>
										<input type="text" placeholder="Search..." required="">	
										<input type="submit" value="">					
									</form>
								</div><!--//end-search-box-->
							<div class="clearfix"> </div>
						 </div>
						
							<!--notification menu end -->
									<div class="profile_details">		
								<ul>
									<li class="dropdown profile_details_drop">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											<div class="profile_img">	
												<span class="prfil-img"><img src="images/img.jpg" style="width:60px;height:60px;"  alt=""> </span> 
												<div class="user-name">
													
												</div>
												<i class="fa fa-angle-down lnr"></i>
												<i class="fa fa-angle-up lnr"></i>
												<div class="clearfix"></div>	
											</div>	
										</a>
										<ul class="dropdown-menu drp-mnu">
											<!--<li> <a href="#"><i class="fa fa-cog"></i> Settings</a> </li> 
											<li> <a href="#"><i class="fa fa-user"></i> Profile</a> </li> -->
											<li> <a href="../logout.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
																				</ul><div class="user-name">
										<?php echo "<font size=3 color = black text-align=right font-size=14px> Welcome: $type " ?></div>	</ul>
									</li>
								
							</div>
							<div class="clearfix"> </div>				
						</div>
				     <div class="clearfix"> </div>	
				</div>

<!-- script-for sticky-nav -->
		<script>
		$(document).ready(function() {
			 var navoffeset=$(".header-main").offset().top;
			 $(window).scroll(function(){
				var scrollpos=$(window).scrollTop(); 
				if(scrollpos >=navoffeset){
					$(".header-main").addClass("fixed");
				}else{
					$(".header-main").removeClass("fixed");
				}
			 });
			 
		});
		</script>

<div class="signup-page-main">
     <div class="signup-main">  	
    	<!-- <div class="signup-head">-->
				<center><h1>ADD EVENTS</h1></center>
			
			<div class="signup-block" >
				<form method="POST" name="myform"> 
				<label>Event Type </label>
					<input type="text" class="long" placeholder="Event Type" id="evt_name"  autocomplete="off" name="evt_name" onChange="return myfunction1()" required="true"/>
<script>
function myfunction1()
{
var x=document.forms["myform"]["evt_name"].value;
if( x == null || x == "" )
{
	$("#name_l").html('Invalid Name..!').fadeIn().delay(4000).fadeOut();
    document.getElementById('evt_name').value = "";
alert("Please Fill Event Field");
document.getElementById('evt_name').focus();
return false;
}
            
 var pattern1 = new RegExp("^[a-zA-Z ]*$"); 
      if(!pattern1.test(document.myform.evt_name.value)) 
	  {
		 // $("#name_l").html('Please fill Name..!').fadeIn().delay(4000).fadeOut();
    document.getElementById('evt_name').value = "";
      alert("Error: Please enter valid Event name!");
      myform.cust_name.focus();
    return false;
     }
  if ((x.length < 3) || (x.length > 20))
  {
	  //$("#name_l").html('Please fill Name..!').fadeIn().delay(4000).fadeOut();
    document.getElementById('evt_name').value = "";
    alert("Event Name  must be 3 to 20 Character");
    document.getElementById("evt_name").focus();
     return false;
   }
    
	 return true;
}
  


</script>



					<label>Event Description</label><br>
					<textarea  rows="4" cols="57" class=long" placeholder="Event Description" id="evt_desc"  autocomplete="off" name="evt_desc" required="true" style="background:#F5F5F5; outline: none;
    border: 1px solid #D3D3D3;   
     border-radius: 5px; font-size: 0.9em;
    padding: 10px 20px;"/></textarea>
					
					<div class="forgot-top-grids">
						
						<div class="clearfix"> </div>
					</div>
					<input type="submit" style="padding: 10px 20px;" name="submit" value="Add Events"/>														
				</form>
				
			</div>
    </div>
</div>


<!--<div class="copyrights">
	 <p>© 2016 Shoppy. All Rights Reserved | Design by  <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
</div>-->	

</div>
</div>

    <div class="sidebar-menu">
		  	<div class="logo"> <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="#"> <span id="logo" ></span> 
			      <!--<img id="logo" src="" alt="Logo"/>--> 
			  </a> </div>		  
		    <div class="menu">
		      <ul id="menu" >
		        
				      <li id="menu-home" ><a href="#"><i class="fa fa-tachometer"></i><span>Approve services</span><span class="fa fa-angle-right" style="float: right"></span></a> 
              
            <ul>
                <li><a href="addeventplanner.php">catering services</a></li>
                <li><a href="add_evt_decor.php">Decorations</a></li>
                <li><a href="add_evt_photo.php">Photography</a></li>
                  <li><a href="add_evt_trans.php">Transportation</a></li>
                <li><a href="add_evt_beauty.php">Beautician</a></li>                                
              </ul>
          </li>
             
           
             <li id="menu-home" ><a href="#"><i class="fa fa-cogs"></i><span>View  services</span><span class="fa fa-angle-right" style="float: right"></span></a> 
              
            <ul>
                <li><a href="viewevent_planner.php">catering services</a></li>
                <li><a href="view_evt_decor.php">Decorations</a></li>
                <li><a href="view_evt_photo.php">Photography</a></li>
                  <li><a href="view_evt_trans.php">Transportation</a></li>
                <li><a href="view_evt_beauty.php">Beautician</a></li>                                
              </ul>
          </li>
		          
		        
		        <li id="menu-home" ><a href="index.html"><i class="fa fa-file-text"></i><span>New Bookings</span></a> </li>
		         
				  <li id="menu-home" ><a href="addevent_type.php"><i class="fa fa-bar-chart"></i><span> Add Events</span></a> </li> 
				   <li id="menu-home" ><a href="viewevent_type.php"><i class="fa fa-cog"></i><span> View Events</span></a> </li> 
			
		         <li  id="menu-home"><a href="#"><i class="fa fa-file-text"></i><span> View Payments</span></a></li>
		         <li  id="menu-home"><a href="#"><i class="fa fa-shopping-cart"></i><span> Make Payments</span></a></li>	
		         
		      </ul>
		    </div>
	 </div>
	<div class="clearfix"> </div>
</div>
<!--slide bar menu end here-->
<script>
var toggle = true;
            
$(".sidebar-icon").click(function() {                
  if (toggle)
  {
    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
    $("#menu span").css({"position":"absolute"});
  }
  else
  {
    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
    setTimeout(function() {
      $("#menu span").css({"position":"relative"});
    }, 400);
  }               
                toggle = !toggle;
            });
</script>
<!--scrolling js-->
		<script src="js3/jquery.nicescroll.js"></script>
		<script src="js3/scripts.js"></script>
		<!--//scrolling js-->
<script src="js3/bootstrap.js"> </script>
<!-- mother grid end here-->
</body>
</html> 
<?php
}
else
header("location:login.php");
?>                    
<?php

if(isset($_POST['submit']))
{
$a=$_POST["evt_name"];
$b=$_POST["evt_desc"];




$p2="insert into event_type(`eventtype_name`,`eventtype_desc`,`eventtype_status`)VALUES('$a','$b',1)";
$ch=mysqli_query($con,$p2);

if($ch)
{?>
	 <script>
 alert("Successfully Added");
</script>
	<?php
}
else
{
	?>
<script>
  //echo"error:".$p2."<br>".mysqli_error($con);
 alert("Event Already Existing ");
 </script>
 <?php
}
}

mysqli_close($con);
?>



                   