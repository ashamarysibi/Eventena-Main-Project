<!--A Design by W3layouts
   Author: W3layout
   Author URL: http://w3layouts.com
   License: Creative Commons Attribution 3.0 Unported
   License URL: http://creativecommons.org/licenses/by/3.0/
   -->
   <?php
include 'conn.php';
$q1="select * from event_type where eventtype_status='1'";
 $db2=mysqli_query($con,$q1);
?>
<?php
session_start();
$login=$_SESSION['login'];
$type=$_SESSION['type'];
$name=$_SESSION['cmp_name'];
if($login)
{
	?>


<!DOCTYPE HTML>
<html>
<head>
<title>Eventena</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Shoppy " />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="css3/bootstrap.css" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="css3/style.css" rel="stylesheet" type="text/css" media="all"/>
<!--js-->
<script src="js3/jquery-2.1.1.min.js"></script> 
<!--icons-css-->
<link href="css3/font-awesome.css" rel="stylesheet"> 
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>
<head>
      <title>Eventena</title>
	  
      <!-- Meta tags -->
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <meta name="keywords" content="Summer Camp Form Responsive Widget, Audio and Video players, Login Form Web Template, Flat Pricing Tables, Flat Drop-Downs, Sign-Up Web Templates, Flat Web Templates, Login Sign-up Responsive Web Template, Smartphone Compatible Web Template, Free Web Designs for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design"
         />
      <script>
         addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); }
      </script>
      <!-- Meta tags -->
      <!-- Calendar -->
      <link rel="stylesheet" href="css2/jquery-ui.css" />
      <!-- //Calendar -->
      <!--stylesheets-->
      <link href="css2/style.css" rel='stylesheet' type='text/css' media="all">
      <!--//style sheet end here-->
      <!-- Google fonts here-->
      <link href="//fonts.googleapis.com/css?family=Barlow:300,400,500" rel="stylesheet">
      <link href="//fonts.googleapis.com/css?family=Josefin+Sans:300,400,600,700" rel="stylesheet">
      <!--//Google fonts here-->
<!--static chart-->
<script src="js3/Chart.min.js"></script>
<!--//charts-->
<!-- geo chart -->
    <script src="//cdn.jsdelivr.net/modernizr/2.8.3/modernizr.min.js" type="text/javascript"></script>
    <script>window.modernizr || document.write('<script src="lib/modernizr/modernizr-custom.js"><\/script>')</script>
    <!--<script src="lib/html5shiv/html5shiv.js"></script>-->
     <!-- Chartinator  -->
    <script src="js3/chartinator.js" ></script>
    
<!--geo chart-->

<!--skycons-icons-->
<script src="js3/skycons.js"></script>
<!--//skycons-icons-->
</head>
<body>	
<div class="page-container">	
   <div class="left-content">
	   <div class="mother-grid-inner">
            <!--header start here-->
				<div class="header-main">
					<div class="header-left">
							<div class="logo-name">
									 <a href="index3.html"> <h1>Eventena</h1> 
									<!--<img id="logo" src="" alt="Logo"/>--> 
								  </a> 	

							</div>
							<!--search-box
								<div class="search-box">
									<form>
										<input type="text" placeholder="Search..." required="">	
										<input type="submit" value="">					
									</form>
								</div><!--//end-search-box-->
							<div class="clearfix"> </div>
						 </div>
						
							<!--notification menu end -->

									<div class="profile_details">		
								<ul>
									<li class="dropdown profile_details_drop">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											<div class="profile_img">	
												<span class="prfil-img"><img src="images/img.jpg" style="width:60px;height:60px;" alt=""> </span> 
												
												<i class="fa fa-angle-down lnr"></i>
												<i class="fa fa-angle-up lnr"></i>
												<div class="clearfix"></div>	
											</div>	
										</a>
										<ul class="dropdown-menu drp-mnu">
											<!--<li> <a href="#"><i class="fa fa-cog"></i> Settings</a> </li> 
											<li> <a href="#"><i class="fa fa-user"></i> Profile</a> </li>--> 
											<li> <a href="trans_profile.php"><i class="fa fa-user"></i> Profile</a> </li> 
                      <li> <a href="../logout.php"><i class="fa fa-sign-out"></i> Logout</a> </li>
										</ul>
										<div class="user-name">
										<?php echo "<font size=4 color = black> $name " ?></div>
									</li>
								</ul>
							</div>
							<div class="clearfix"> </div>			
						</div>
				   <div class="clearfix"> </div>
				</div>






<!--slide bar menu end here-->
      <div class="main-bothside">
         <form action="#" name="myform" method="post" enctype="multipart/form-data">
            <div class="main-title">
               <h2>Add Vehicle</h2>
            </div>

            <div class="form-group">
			<div class="form-grid-w3ls">

			   <label>Vehicle Name</label>
                  <input type="text"  name="name" id="name" placeholder="Vehicle Name"  onChange="return myfunction3()"required/>
				  </div>
  <script>
function myfunction3()

{
var x=document.forms["myform"]["name"].value;
if(x=="")
{
alert("Please Fill Vehicle name Field");
document.getElementById('name').focus();
document.getElementById('name').value = "";
return false;
}
 var pattern1 = new RegExp("^[a-zA-Z ]*$"); 
      if(!pattern1.test(document.myform.name.value)) 
    {
      alert("Error: Please enter valid Vehicle name!");
    document.getElementById('name').value = "";
      myform.name.focus();
    return false;
     }


 if ((x.length < 3) || (x.length > 30))
  {
    alert("Your vehicle Name must be 3 to 30 Character");
    document.getElementById('name').focus();
  document.getElementById('name').value = "";
     return false;
   }

  
    


return (true);
}

  </script>
			
               <div class="form-grid-w3ls">

			   <label> Color</label>
			   
          <input type="text"  name="color" id="color" placeholder="color"  onChange="return myfunction2()" required/>        
                           
	</div>
                            <script>
function myfunction2()

{
var x=document.forms["myform"]["color"].value;
if(x=="")
{
alert("Please Fill color Field");
document.getElementById('color').focus();
document.getElementById('color').value = "";
return false;
}
 var pattern1 = new RegExp("^[a-zA-Z ]*$"); 
      if(!pattern1.test(document.myform.color.value)) 
    {
      alert("Error: Please enter valid color!");
    document.getElementById('color').value = "";
      myform.color.focus();
    return false;
     }


 if ((x.length < 3) || (x.length > 30))
  {
    alert("Your color must be 3 to 30 Character");
    document.getElementById('color').focus();
  document.getElementById('color').value = "";
     return false;
   }

  
    


return (true);
}

  </script>
	</div> 
	<div class="form-group">
           
                            
	<div class="form-grid-w3ls">
			   <label>seats</label><br>
         <input type="text"  name="seat" id="seat" placeholder="seats" onChange="return myfunction1()" required/>               
          <script>
function myfunction1()
{
  var h=document.forms["myform"]["seat"].value;
if(h=="")
{
alert("Please Fill seat Field");
document.getElementById('seat').focus();
return false;
}
if(isNaN(h))
  {
    alert("Please Enter valid seat value");
    document.getElementById("seat").focus();
  document.getElementById('seat').value = "";
     return false;
  }
  if ((h.length < 0) || (h.length > 7))
  {
    alert("Please enter a valid seat value");
    document.getElementById("seat").focus();
  document.getElementById('seat').value = "";
     return false;
   }
   return (true);
}
</script>     
			</div>

      <div class="form-grid-w3ls">
         <label>Air Conditioning</label><br>
          <select class="form-control buttom" name="ac" id="ac" required/>
                     <option value="">Category</option>  
                     <option value="Ac">AC</option>              
                     <option value="Non Ac">Non AC</option> 
                   </select>
            
      </div>

      </div>
			<div class="form-group">
               
          
           
				 <div class="form-grid-w3ls">
         <label>Driver Type</label><br>
          <select class="form-control buttom" name="driver" id="driver" required/>
                     <option value="">Category</option>  
                     <option value="self Drive">Self Drive</option>              
                     <option value="Driver service">Driver service</option> 
                   </select></div>
                      <div class="form-grid-w3ls">
         <label>Price/Day</label>
          <input type="text"  name="price" id="price" placeholder="Price" onChange="return myfunction7()" required/>
      
       <script>
function myfunction7()
{
  var h=document.forms["myform"]["price"].value;
if(h=="")
{
alert("Please Fill price Field");
document.getElementById('price').focus();
return false;
}
if(isNaN(h))
  {
    alert("Please Enter valid price");
    document.getElementById("price").focus();
  document.getElementById('price').value = "";
     return false;
  }
  if ((h.length < 0) || (h.length > 7))
  {
    alert("Please enter a valid price value");
    document.getElementById("price").focus();
  document.getElementById('price').value = "";
     return false;
   }
   return (true);
}
</script>  
</div></div>
				 
	 <div class="form-group">
         <div class="form-grid-w3ls">

      &nbsp;&nbsp;&nbsp; <label>Image</label>
                 &nbsp;&nbsp;&nbsp; <input type="file"  name="img1"  id="img1" onChange="return checkfiles()" required/>
          
          <script>          
function checkfiles() {
    var formData = new FormData();
 
    var file = document.getElementById("img1").files[0];
 
    formData.append("Filedata", file);
    var t = file.type.split('/').pop().toLowerCase();
    if (t != "jpeg" && t != "jpg" && t != "png" && t != "bmp" && t != "gif") {
        alert('Please select a valid image file');
        document.getElementById("img1").value = '';
        return false;
    }
    if (file.size > 1024000) {
        alert('Max Upload size is 1MB only');
        document.getElementById("img1").value = '';
        return false;
    }
    return true;
}
</script>
            
           
            </div>

            </div>
            <div class="form-grid-w3ls">
	
      <center><input type="submit" name="upload" value="Add Vehicle"></center>
   </form>
		 </div>	
      </div></div>
      <div class="copy">
         <p>©2019 Site  Designed by Asha Mary Sibi</a></p>
      </div>
      <!-- js -->
      <script src='js/jquery-2.2.3.min.js'></script>
      <!-- //js -->
      <!-- Calendar -->
      <script src="js/jquery-ui.js"></script>
      <script>
         $(function () {
         	$("#datepicker,#datepicker1,#datepicker2,#datepicker3").datepicker();
         });
      </script>
      <!-- //Calendar -->
</form>
  <div class="sidebar-menu">
		  	<div class="logo"> <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="#"> <span id="logo" ></span> 
			      <!--<img id="logo" src="" alt="Logo"/>-->
			  </a> </div>		  
		    <div class="menu">
		      <ul id="menu" >
		          <li id="menu-home" ><a href="add_trans.php"><i class="fa fa-tachometer"></i><span>Add Vehicle</span></a></li>
             
            </li>
             <li id="menu-home" ><a href="view_trans.php"><i class="fa fa-cogs"></i><span>View vehicle</span></a> </li>
              
            
            <li id="menu-home" ><a href="#"><i class="fa fa-file-text"></i><span>New Bookings</span></a> </li>
             
          <li id="menu-home" ><a href="#"><i class="fa fa-bar-chart"></i><span>Booking History</span></a> </li> 
          <!-- <li id="menu-home" ><a href="viewevent_type.php"><i class="fa fa-cog"></i><span> View Events</span></a> </li> -->
      
             <li  id="menu-home"><a href="#"><i class="fa fa-bar-chart"></i><span> View Payments</span></a></li>
             <li  id="menu-home"><a href="#"><i class="fa fa-shopping-cart"></i><span> Make Payments</span></a></li>
<li id="menu-home" ><a href="change_pswd_trans.php"><i class="fa fa-file-text"></i><span>change Password</span></a> </li>				 
		         
			      </ul>
		    </div>
	 </div>

	<div class="clearfix"> </div>
</div>
<!--slide bar menu end here-->
<script>
var toggle = true;
            
$(".sidebar-icon").click(function() {                
  if (toggle)
  {
    $(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
    $("#menu span").css({"position":"absolute"});
  }
  else
  {
    $(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
    setTimeout(function() {
      $("#menu span").css({"position":"relative"});
    }, 400);
  }               
                toggle = !toggle;
            });
</script>
<!--scrolling js-->
		<script src="js3/jquery.nicescroll.js"></script>
		<script src="js3/scripts.js"></script>
		<!--//scrolling js-->
<script src="js3/bootstrap.js"> </script>
</html>  
<?php
}
else
header("location:login.php");
?>
<html>

</body>
</html>
<!DOCTYPE html>
<html lang="en">
   
   </head>
   <body>
      
	  

      <script>
         $(function () {
         	$("#datepicker,#datepicker1,#datepicker2,#datepicker3").datepicker();
         });
      </script>
      <!-- //Calendar -->
   </body>
</html>

<?php
$msg = "";
if(isset($_POST['upload'])){
	$u_id=$_SESSION['loginid'];
  $qry=mysqli_query($con,"select evt_trans_id from evt_trans where log_id='$u_id'");
  $r=mysqli_fetch_array($qry,MYSQLI_ASSOC);
	$lid=$r['evt_trans_id'];
	
	 $pack= $_POST['name'];
   $color = $_POST['color'];
   $seat = $_POST['seat'];
   $ac = $_POST['ac'];
	 $price = $_POST['price'];	
   $drive = $_POST['driver'];
   $img =$_FILES['img1']['name'];
   $temp_name =$_FILES['img1']['tmp_name'];
   move_uploaded_file($temp_name,'../uploads/' .$img);

    $sql = "insert into tbl_transport (evt_trans_id,trans_name,trans_color,trans_seat,trans_ac,trans_drvr,trans_price,trans_image,trans_status) values('$lid','$pack','$color','$seat','$ac','$drive','$price','$img','1')";
     $ch=mysqli_query($con,$sql);
      
      if($ch)
{?>
	 <script>
 alert(" Vehicle Added");
  window.location="add_trans.php";
</script>
	<?php
}
else
{
 
   
 echo"error:".$ch."<br>".mysqli_error($con);


	}
	}
	


?>





	
	
	


