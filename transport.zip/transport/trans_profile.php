   <?php
include 'conn.php';
?>
<?php

session_start();
$login=$_SESSION['login'];
$type=$_SESSION['type'];
$name=$_SESSION['cmp_name'];
if($login)
{
?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <title>Eventena</title>
      <!-- Meta tags -->
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <meta name="keywords" content="Summer Camp Form Responsive Widget, Audio and Video players, Login Form Web Template, Flat Pricing Tables, Flat Drop-Downs, Sign-Up Web Templates, Flat Web Templates, Login Sign-up Responsive Web Template, Smartphone Compatible Web Template, Free Web Designs for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design"
         />
      <script>
         addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); }
      </script>
      <!-- Meta tags -->
      <!-- Calendar -->
      <link rel="stylesheet" href="css2/jquery-ui.css" />
      <!-- //Calendar -->
      <!--stylesheets-->
      <link href="css2/style.css" rel='stylesheet' type='text/css' media="all">
      <!--//style sheet end here-->
      <!-- Google fonts here-->
      <link href="//fonts.googleapis.com/css?family=Barlow:300,400,500" rel="stylesheet">
      <link href="//fonts.googleapis.com/css?family=Josefin+Sans:300,400,600,700" rel="stylesheet">
      <!--//Google fonts here-->
   </head>
   <body>
      <h1 class="header-w3ls">
         Eventena
      </h1>
	  <a href="trans_session.php" style="color: white; 
    width: 50%;
    padding: 5px 5px;
	text-decoration: none;
	 margin:0px 10px; font-size: 23px; padding:  5px 990px;"> Home </a>
	 <?php
	 $lid=$_SESSION['loginid'];

if($lid>0){
	

	
	$select="select * from `evt_trans` where log_id='$lid'";
	
	$data=mysqli_query($con,$select);
	$row=mysqli_fetch_array($data);
	?>
      <!-- multistep form -->
      <div class="main-bothside">
         <form action="#" name="myform" method="post" enctype="multipart/form-data">
            <div class="main-title">
               <h2> My Profile</h2>
            </div>
            <div class="form-group">
               <div class="form-grid-w3ls">
			   <label>company Name</label>
                  <input type="text" value="<?php echo $row['cmp_name'];?>" class="long"  id="evt_name" name="evt_name" autocomplete="off" onChange="return myfunction1()"  required/>


<script>
function myfunction1()
{
var x=document.forms["myform"]["evt_name"].value;
if( x == null || x == "" )
{
	$("#name_l").html('Invalid Name..!').fadeIn().delay(4000).fadeOut();
    document.getElementById('evt_name').value = "";
alert("Please Fill name Field");
document.getElementById('evt_name').focus();
return false;
}
            
 var pattern1 = new RegExp("^[a-zA-Z ]*$"); 
      if(!pattern1.test(document.myform.evt_name.value)) 
	  {
		 // $("#name_l").html('Please fill Name..!').fadeIn().delay(4000).fadeOut();
    document.getElementById('evt_name').value = "";
      alert("Error: Please enter valid name!");
      myform.cust_name.focus();
    return false;
     }
  if ((x.length < 3) || (x.length > 20))
  {
	  //$("#name_l").html('Please fill Name..!').fadeIn().delay(4000).fadeOut();
    document.getElementById('evt_name').value = "";
    alert("Your Name  must be 3 to 20 Character");
    document.getElementById("evt_name").focus();
     return false;
   }
    
	 return true;
}
  


</script>
               </div>
               <div class="form-grid-w3ls">
			   <label>Owner Name</label>
                  <input type="text" class="long"  value="<?php echo $row['cmp_owner'];?>" id="evt_own" autocomplete="off" name="evt_own" onChange="return myfunction2()" required/>
              
<script>
function myfunction2()
{
	var a=document.forms["myform"]["evt_own"].value;
if(a=="")
{
	document.getElementById('evt_own').value = "";
alert("Please Fill Owner Name Field");
document.getElementById('evt_own').focus();

return false;
}
var pattern = new RegExp("^[a-zA-Z ]*$"); 
      if(!pattern.test(document.myform.evt_own.value)) 
	  {
      alert("Error: Please enter valid Owner name!");
	  document.getElementById('evt_own').value = "";
      myform.cust_name.focus();
    return false;
     }
 if ((a.length < 3) || (a.length > 20))
  {
	  document.getElementById('evt_own').value = "";
    alert("Your Owner Name must be 3 to 20 Character");
    
	
	document.getElementById("evt_own").focus();
     return false;
   }
   
  return true;

}
</script>
	</div>
            </div>
            <div class="form-group">
               
			   
               <div class="form-grid-w3ls">
			   <label>Location</label>
                 <input type="text" value="<?php echo $row['cmp_addr'];?>"  name="evt_addr" id="evt_addr" autocomplete="off"  required="true" onChange="return myfunction4()"/>

<script>
function myfunction4()
{ var f=document.forms["myform"]["evt_addr"].value;
if(f=="")
{
alert("Please Fill address Field");
document.getElementById('evt_addr').focus();
return false;
} 
return (true);
}
</script>         </div>
            
            
            
               
            
               <div class="form-grid-w3ls">
			   <label>Website</label>
                  <input type="text" value="<?php echo $row['cmp_website'];?>" class="long" id="website" autocomplete="off"  required="true" name="website"  onChange="return myfunction5()"/>    

<script>
function myfunction5()
{
var g=document.forms["myform"]["website"].value;
if(g=="")
{
alert("Please Fill website Field");
document.getElementById('website').focus();
return false;
}
var patt = new RegExp('^(https?:\\/\\/)?'+ // protocol
    '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ // domain name
    '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
    '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ // port and path
    '(\\?[;&a-z\\d%_.~+=-]*)?'+ // query string
    '(\\#[-a-z\\d_]*)?$','i'); 
	if(!patt.test(g))
	{
alert("Please enter valid website");
document.getElementById('website').focus();	
document.getElementById('website').value = "";
return false;	
	}	
return (true);
}
  </script>  

 
 
         
</div>
               </div>
			    <div class="form-group">
               <div class="form-grid-w3ls">
			   <label>Contact</label>
                  <input type="text"  id="contact" value="<?php echo $row['cmp_contact'];?>"  autocomplete="off"  required="true"  name="contact"  onChange="return myfunction6()"/>   

<script>
function myfunction6()
{
	if( document.myform.contact.value == "" ||
           isNaN( document.myform.contact.value) ||
           document.myform.contact.value.length != 10 )
   {
     alert( "Please provide a Mobile No  upto 10 digit" );
   document.getElementById('contact').focus();
   document.getElementById('contact').value = "";
     return false;
   }
    var patt = new RegExp("^([6-9]{1})([0-9]{9})$"); 
      if(!patt.test(document.myform.contact.value)) 
	  {
      alert("Error: Phone Number is invalid!");
	  document.getElementById('contact').value = "";
       document.getElementById('contact').focus();
    return false;
     }
	 return (true);
}
	</script>  
               </div>
         
			
               
			 
               <div class="form-grid-w3ls">
			   <label>Experience in Months</label>
                 <input type="text" id="exp_mnt" value="<?php echo $row['exp_mnt'];?>"   required="true" autocomplete="off" name="exp_mnt"  onChange="return myfunction8()"/> 
              
<script>
function myfunction8()
{
	
   var i=document.forms["myform"]["exp_mnt"].value;
if(i=="")
{
alert("Please Fill Experience in months Field");
document.getElementById('exp_mnt').focus();
return false;
}
if(isNaN(i))
  {
    alert("Please Enter Only Numbers as Experience months");
    document.getElementById("exp_mnt").focus();
	document.getElementById('exp_mnt').value = "";
     return false;
  }
    if ((i.length < 0) || (i.length > 12))
  {
    alert("Please enter a valid  Experience months");
    document.getElementById("exp_mnt").focus();
	document.getElementById('exp_mnt').value = "";
     return false;
   }
   return (true);
}
	</script>  
	</div>
            
                
			</div>
               

  

           
            <?php 
}	
?>
               <div class="form-grid-w3ls">
            
            <!--<div class="form-control-w3l">
               <textarea name="Message" placeholder="Any Message..."></textarea>
            </div>-->
            <center><input type="submit"  name="submit" value="Update"></center>
         </div></form>
      </div>
      <div class="copy">
         <p>©2019 Site  Designed by Asha Mary Sibi</a></p>
      </div>
      <!-- js -->
      <script src='js/jquery-2.2.3.min.js'></script>
      <!-- //js -->
      <!-- Calendar -->
      <script src="js/jquery-ui.js"></script>
      <script>
         $(function () {
         	$("#datepicker,#datepicker1,#datepicker2,#datepicker3").datepicker();
         });
      </script>
      <!-- //Calendar -->
   </body>
</html>
<?php
}
else
header("location:login.php");
?>	
<?php
include("conn.php");


if(isset($_POST['submit']))
{
	
   $a=$_POST["evt_name"];
$b=$_POST["evt_own"];

$c=$_POST["evt_addr"];
$d=$_POST["website"];
$e=$_POST["contact"];

$g=$_POST["exp_mnt"];



	
$p2="update `evt_trans`
set 
  `cmp_name` = '$a',
  `cmp_owner` = '$b',
  `cmp_addr` = '$c',
  `cmp_website` = '$d',
  `cmp_contact` = '$e',
  
  `exp_mnt` = '$g'
where `log_id` ='$lid'";
$ch=mysqli_query($con,$p2); 
	
if($ch)
{?>
	 <script>
 alert(" Updated");
   window.location="trans_profile.php";
</script>
	<?php
}
else
{
  ?>
	 <script>
 alert(" Error");
   window.location="trans_profile.php";
</script>
	<?php
   
}

}

?> 

