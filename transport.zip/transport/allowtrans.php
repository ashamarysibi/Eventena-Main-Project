<?php
include "conn.php";

$b=$_POST['id'];
 
$sql=mysqli_query($con,"update tbl_transport set trans_status='1' where trans_id='$b'");

if ( $sql  ){
echo "<script>alert(' Blocked');
     //window.location='view_dec_item.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
 header("location:view_trans.php")
 ?>