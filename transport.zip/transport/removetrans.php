<?php
include "conn.php";

$b=$_POST['id'];
 
$sql=mysqli_query($con,"update tbl_transport set trans_status='0' where trans_id='$b'");

if ( $sql  ){
echo "<script>alert(' Blocked')";
     
}
else {
	echo "<script>alert('Error');</script>";
}
 header("location:view_trans.php")
 ?>