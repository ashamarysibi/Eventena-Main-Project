<!--A Design by W3layouts
   Author: W3layout
   Author URL: http://w3layouts.com
   License: Creative Commons Attribution 3.0 Unported
   License URL: http://creativecommons.org/licenses/by/3.0/
   -->
   <?php
include 'conn.php';
?>
<!DOCTYPE html>
<html lang="en">
   <head>
      <title>Eventena</title>
      <!-- Meta tags -->
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <meta name="keywords" content="Summer Camp Form Responsive Widget, Audio and Video players, Login Form Web Template, Flat Pricing Tables, Flat Drop-Downs, Sign-Up Web Templates, Flat Web Templates, Login Sign-up Responsive Web Template, Smartphone Compatible Web Template, Free Web Designs for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design"
         />
      <script>
         addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); }
      </script>
      <!-- Meta tags -->
      <!-- Calendar -->
      <link rel="stylesheet" href="css2/jquery-ui.css" />
      <!-- //Calendar -->
      <!--stylesheets-->
      <link href="css2/style.css" rel='stylesheet' type='text/css' media="all">
      <!--//style sheet end here-->
      <!-- Google fonts here-->
      <link href="//fonts.googleapis.com/css?family=Barlow:300,400,500" rel="stylesheet">
      <link href="//fonts.googleapis.com/css?family=Josefin+Sans:300,400,600,700" rel="stylesheet">
      <!--//Google fonts here-->
   </head>
   <body>
      <h1 class="header-w3ls">
         Eventena
      </h1>
	  <a href="../Home/index.html" style="color: white; 
    width: 50%;
    padding: 5px 5px;
	text-decoration: none;
	 margin:0px 10px; font-size: 23px; padding:  5px 990px;"> Home </a>
      <!-- multistep form -->
          <div class="main-bothside">
         <form action="#" name="myform" method="post" enctype="multipart/form-data">
            <div class="main-title">
               <h2> Transportation Registration Form</h2>
            </div>
            <div class="form-group">
               <div class="form-grid-w3ls">
			   <label>Company Name</label>
                  <input type="text"  class="long" placeholder="Company Name" id="evt_name" name="evt_name" autocomplete="off" onChange="return myfunction1()"  required/>

<label class="errortext" style="display:nne; color: red;" id="name_l"></label>
<script>
function myfunction1()
{
var x=document.forms["myform"]["evt_name"].value;
if( x == null || x == "" )
{
	$("#name_l").html('Invalid Name..!').fadeIn().delay(4000).fadeOut();
    document.getElementById('evt_name').value = "";
alert("Please Fill name Field");
document.getElementById('evt_name').focus();
return false;
}
            
 var pattern1 = new RegExp("^[a-zA-Z ]*$"); 
      if(!pattern1.test(document.myform.evt_name.value)) 
	  {
		 // $("#name_l").html('Please fill Name..!').fadeIn().delay(4000).fadeOut();
    document.getElementById('evt_name').value = "";
      alert("Error: Please enter valid name!");
      myform.cust_name.focus();
    return false;
     }
  if ((x.length < 3) || (x.length > 20))
  {
	  //$("#name_l").html('Please fill Name..!').fadeIn().delay(4000).fadeOut();
    document.getElementById('evt_name').value = "";
    alert("Your Name  must be 3 to 20 Character");
    document.getElementById("evt_name").focus();
     return false;
   }
    
	 return true;
}
  


</script>
               </div>
               <div class="form-grid-w3ls">
			   <label>Owner Name</label>
                  <input type="text" class="long" placeholder=" Owner Name" id="evt_own" autocomplete="off" name="evt_own" onChange="return myfunction2()" required/>
               <label class="errortext" style="display:nne; color: red;" id="name_2"></label>
<script>
function myfunction2()
{
	var a=document.forms["myform"]["evt_own"].value;
if(a=="")
{
	document.getElementById('evt_own').value = "";
alert("Please Fill Owner Name Field");
document.getElementById('evt_own').focus();

return false;
}
var pattern = new RegExp("^[a-zA-Z ]*$"); 
      if(!pattern.test(document.myform.evt_own.value)) 
	  {
      alert("Error: Please enter valid Owner name!");
	  document.getElementById('evt_own').value = "";
      myform.cust_name.focus();
    return false;
     }
 if ((a.length < 3) || (a.length > 20))
  {
	  document.getElementById('evt_own').value = "";
    alert("Your Owner Name must be 3 to 20 Character");
    
	
	document.getElementById("evt_own").focus();
     return false;
   }
   
  return true;

}
</script>
	</div>
            </div>
               <div class="form-group">
               <div class="form-grid-w3ls">
			   <label>Location</label>
                 <input type="text"  name="evt_addr" id="evt_addr" autocomplete="off" placeholder="Location"  required="true" onChange="return myfunction4()"/>
               <label class="errortext" style="display:nne; color: red;" id="name_4"></label>
<script>
function myfunction4()
{ var f=document.forms["myform"]["evt_addr"].value;
if(f=="")
{
alert("Please Fill address Field");
document.getElementById('evt_addr').focus();
return false;
} 
return (true);
}
</script>         </div>
            
               <div class="form-grid-w3ls">
			   <label>Website</label>
                  <input type="text" class="long" id="website" autocomplete="off"  required="true" placeholder="website " name="website"  onChange="return myfunction5()"/>    

<script>
function myfunction5()
{
var g=document.forms["myform"]["website"].value;
if(g=="")
{
alert("Please Fill website Field");
document.getElementById('website').focus();
return false;
}
var patt = new RegExp('^(https?:\\/\\/)?'+ // protocol
    '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|'+ // domain name
    '((\\d{1,3}\\.){3}\\d{1,3}))'+ // OR ip (v4) address
    '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*'+ // port and path
    '(\\?[;&a-z\\d%_.~+=-]*)?'+ // query string
    '(\\#[-a-z\\d_]*)?$','i'); 
	if(!patt.test(g))
	{
alert("Please enter valid website");
document.getElementById('website').focus();	
document.getElementById('website').value = "";
return false;	
	}	
return (true);
}
  </script>  

 
 
         

               </div></div>
			      <div class="form-group">
               <div class="form-grid-w3ls">
			   <label>Contact</label>
                  <input type="text"  id="contact" placeholder="contact " autocomplete="off"  required="true"  name="contact"  onChange="return myfunction6()"/>   

<script>
function myfunction6()
{
	if( document.myform.contact.value == "" ||
           isNaN( document.myform.contact.value) ||
           document.myform.contact.value.length != 10 )
   {
     alert( "Please provide a Mobile No  upto 10 digit" );
   document.getElementById('contact').focus();
   document.getElementById('contact').value = "";
     return false;
   }
    var patt = new RegExp("^([6-9]{1})([0-9]{9})$"); 
      if(!patt.test(document.myform.contact.value)) 
	  {
      alert("Error: Phone Number is invalid!");
	  document.getElementById('contact').value = "";
       document.getElementById('contact').focus();
    return false;
     }
	 return (true);
}
	</script>  
               </div>
           
			<div class="form-grid-w3ls">
			   <label>Username</label>
                  <input type="email" name="username" id="username" autocomplete="none"  required="true" placeholder="Username(Emailid)"  onChange="return myfunction10()" />
               <label class="errortext" style="display:nne; color: red;" id="name_l0"></label>
<script>
function myfunction10()
{
	var f=document.forms["myform"]["username"].value;
if(f=="")
{
alert("Please Fill username Field");
document.getElementById('username').focus();
return false;
}
var uname = document.myform.username.value;
  atpos = uname.indexOf("@");
  dotpos = uname.lastIndexOf(".");
  if (uname == "" || atpos < 1 || ( dotpos - atpos < 2 )) 
  {
     alert("Please enter an Email-id as username");
	 document.getElementById('username').value = "";
   document.getElementById('username').focus();
     return false;
  }
  return (true);
}
	</script>  </div>
            </div>
                  <div class="form-group">  
			<div class="form-grid-w3ls">
			   <label>Experience in Months</label>
                  <input type="text" id="exp_yr" placeholder="Experience in Months "    required="true" autocomplete="off" name="exp_mnt"  onChange="return myfunction7()"/> 



<script>
function myfunction7()
{
	var h=document.forms["myform"]["exp_yr"].value;
if(h=="")
{
alert("Please Fill Experience in years Field");
document.getElementById('exp_yr').focus();
return false;
}
if(isNaN(h))
  {
    alert("Please Enter Only Numbers as Experience year");
    document.getElementById("exp_yr").focus();
	document.getElementById('exp_yr').value = "";
     return false;
  }
  if ((h.length < 0) || (h.length > 4))
  {
    alert("Please enter a valid Experience Year");
    document.getElementById("exp_yr").focus();
	document.getElementById('exp_yr').value = "";
     return false;
   }
   return (true);
}
</script>  

               </div>
			       <div class="form-grid-w3ls">
			   <label>Password</label>
                  <input type="password" name="log_pswd" id="log_pswd"  autocomplete="off"  required="true"  placeholder="password"  onChange="return myfunction11()"/>
<font color="red">  <p>* password should contain  uppercase,lowercase,digit and special characters</p></font>
<label class="errortext" style="display:nne; color: red;" id="name_l1"></label>
<script>
function myfunction11()
{
	var o=document.forms["myform"]["log_pswd"].value;
if(o=="")
{
alert("Please Fill password Field");
document.getElementById('log_pswd').focus();
return false;
}
if(o.length<8){  
   alert("Password must be at least 8 characters long.");  
   document.getElementById('log_pswd').value = "";
    return false;  
}
var strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})"); 
  if(!strongRegex.test(document.myform.log_pswd.value)) 
	  {
      alert("Error: password should contain atleast one uppercase ,lowercase , digit and special characters!");
      document.getElementById('log_pswd').value = "";
	  myform.log_pswd.focus();
    return false;
     } 
return (true);
}
</script>  


               </div></div> 
			  <div class="form-group"> 
               <div class="form-grid-w3ls">
			   <label>Licence Number</label>
                  <input type="text" class="long" id="licence" placeholder="Licence Number"  required="true"  autocomplete="off" name="licence"  onChange="return myfunction9()"/> 
<label class="errortext" style="display:nne; color: red;" id="name_9"></label>
<script>
function myfunction9()
{
var j=document.forms["myform"]["licence"].value;
if(j=="")
{
alert("Please Fill licence Field");
document.getElementById('licence').focus();
return false;
}
if(isNaN(j))
  {
    alert("Please Enter Only Numbers as Licence Number");
    document.getElementById("licence").focus();
	document.getElementById('licence').value = "";
     return false;
  }
if((j.length < 14) || (j.length > 14)) 
{
alert("Please enter a valid licence Number upto 14 digits");
document.getElementById('licence').value = "";
document.getElementById('licence').focus();
return false;	
}


return (true);
}
</script>  





               </div>
			  
			   <div class="form-grid-w3ls">
			   <label> Confirm Password</label>
                 <input type="password" name="log_pswd2" id="log_pswd2" autocomplete="off"  required="true" placeholder="confirm Password"  onChange="return myfunction12()"/>
               <label class="errortext" style="display:nne; color: red;" id="name_l2"></label>
<script>
function myfunction12()
{
	var h=document.forms["myform"]["log_pswd2"].value;
if(h=="")
{
alert("Please Fill confirm password Field");
document.getElementById('log_pswd2').focus();
return false;
}
var pwd = document.getElementById("log_pswd").value;
       var cpwd = document.getElementById("log_pswd2").value;
        if (pwd != cpwd) {
            alert("Passwords do not match.");
			document.getElementById('log_pswd').focus();
			document.getElementById('log_pswd').value = "";
			document.getElementById('log_pswd2').value = "";
            return false;
        }
return (true);
}
	</script>  
	</div>
            </div>
			  <div class="form-group">
				 <div class="form-grid-w3ls">
				<label>Scanned Licence document</label>
                  <input type="file"  name="img3" id="img3" onChange="return checkfiles3()" required/>
				<script>				  
function checkfiles3() {
    var formData = new FormData();
 
    var file = document.getElementById("img3").files[0];
 
    formData.append("Filedata", file);
    var t = file.type.split('/').pop().toLowerCase();
    if (t != "docx" && t != "pdf" ) {
        alert('Please select a valid  file TYpe');
        document.getElementById("img3").value = '';
        return false;
    }
    if (file.size > 1024000) {
        alert('Max Upload size is 1MB only');
        document.getElementById("img3").value = '';
        return false;
    }
    return true;
}
</script>
</div>

</div>
            <!--<div class="form-control-w3l">
               <textarea name="Message" placeholder="Any Message..."></textarea>
            </div>-->
            <center><input type="submit"  name="submit" value="Submit"></center>
         </form>
      </div>
      <div class="copy">
         <p>©2019 Site  Designed by Asha Mary Sibi</a></p>
      </div>
      <!-- js -->
      <script src='js/jquery-2.2.3.min.js'></script>
      <!-- //js -->
      <!-- Calendar -->
      <script src="js/jquery-ui.js"></script>
      <script>
         $(function () {
         	$("#datepicker,#datepicker1,#datepicker2,#datepicker3").datepicker();
         });
      </script>
      <!-- //Calendar -->
   </body>
</html>
<?php

if(isset($_POST['submit']))
{
$a=$_POST["evt_name"];
$b=$_POST["evt_own"];

$c=$_POST["evt_addr"];
$d=$_POST["website"];
$e1=$_POST["contact"];
$f=$_POST["exp_mnt"];

$h=$_POST["licence"];
$u=$_POST["username"];
$e=$_POST["log_pswd"];

$q2="insert into tbl_login(`usertype_id`,`username`,`log_pswd`,`status`) values(7,'$u','$e',0)";
if(mysqli_query($con,$q2))
{
	$s=mysqli_query($con,"select log_id from tbl_login where username='$u' and log_pswd='$e'" );
	$r=mysqli_fetch_array($s,MYSQLI_ASSOC);
	$lid=$r['log_id'];
	
	$img3 =$_FILES['img3']['name'];
$temp_name =$_FILES['img3']['tmp_name'];
move_uploaded_file($temp_name,'../uploads/certificate/' .$img3);

$p2="insert into evt_trans(`log_id`,`cmp_name`,`cmp_owner`,`cmp_category`,`cmp_addr`,`cmp_website`,`cmp_contact`,`exp_mnt`,`cmp_licnc`,`lic_doc`,`cmp_status`)VALUES('$lid','$a','$b','Transportation','$c','$d','$e1','$f','$h','$img3',0)";
$ch=mysqli_query($con,$p2);

if($ch)
{?>
	 <script>
 alert("Registeration Successfull");
  window.location="../login.php";
</script>
	<?php
}
else
{
  echo"error:".$p2."<br>".mysqli_error($con);
  alert("Error ");
}
}
else
{?>
	<script>
 alert("Username  Already Exists ");
</script>";
<?php
}

}
mysqli_close($con);
	
	
	?>



