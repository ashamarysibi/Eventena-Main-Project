<?php
include "conn.php";

$b=$_POST['id'];
 
$sql=mysqli_query($con,"update tbl_status set trans_status='1' where book_id='$b'");

if ( $sql  ){
echo "<script>alert(' service Provided');
     window.location='new_book_trans.php';</script>";
}
else {
	echo "<script>alert('Error');</script>";
}
 header("location:new_book_trans.php")
 ?>